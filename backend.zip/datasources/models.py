import uuid

from django.conf import settings
from django.db import models

from workspaces.models import Workspace


class DataSource(models.Model):
    class Mode(models.TextChoices):
        MANAGED = "MANAGED", "Administrada por la plataforma"
        EXTERNAL = "EXTERNAL", "Base externa"
        PRIVATE_GATEWAY = "PRIVATE_GATEWAY", "Gateway privado"

    class Engine(models.TextChoices):
        PLATFORM_POSTGRES = "PLATFORM_POSTGRES", "PostgreSQL administrado"
        POSTGRESQL = "POSTGRESQL", "PostgreSQL"
        SQLSERVER = "SQLSERVER", "Microsoft SQL Server"
        OTHER = "OTHER", "Otro"

    class Status(models.TextChoices):
        DRAFT = "DRAFT", "Borrador"
        ACTIVE = "ACTIVE", "Activa"
        UNAVAILABLE = "UNAVAILABLE", "No disponible"
        ARCHIVED = "ARCHIVED", "Archivada"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    workspace = models.ForeignKey(
        Workspace,
        on_delete=models.CASCADE,
        related_name="data_sources",
    )
    name = models.CharField(max_length=180)
    mode = models.CharField(max_length=30, choices=Mode.choices)
    engine = models.CharField(max_length=40, choices=Engine.choices)
    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        default=Status.DRAFT,
    )

    can_read = models.BooleanField(default=True)
    can_write = models.BooleanField(default=False)
    can_ddl = models.BooleanField(default=False)

    # Solo metadatos no sensibles. Credenciales reales se implementarán
    # en la fase de connectors/governance.
    connection_metadata = models.JSONField(default=dict, blank=True)

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="data_sources_created",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(
                fields=["workspace", "name"],
                name="unique_datasource_name_per_workspace",
            )
        ]

    def __str__(self):
        return f"{self.workspace} / {self.name}"


class DataAsset(models.Model):
    class AssetType(models.TextChoices):
        TABLE = "TABLE", "Tabla"
        VIEW = "VIEW", "Vista"
        DERIVED_TABLE = "DERIVED_TABLE", "Tabla derivada"
        DATASET = "DATASET", "Dataset"
        METRIC = "METRIC", "Métrica"
        CHART = "CHART", "Gráfico"
        DASHBOARD = "DASHBOARD", "Dashboard"
        REPORT = "REPORT", "Reporte"
        ML_MODEL = "ML_MODEL", "Modelo ML"
        OPTIMIZATION_MODEL = "OPTIMIZATION_MODEL", "Modelo de optimización"
        OTHER = "OTHER", "Otro"

    class Status(models.TextChoices):
        ACTIVE = "ACTIVE", "Activo"
        STALE = "STALE", "Desactualizado"
        ARCHIVED = "ARCHIVED", "Archivado"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    workspace = models.ForeignKey(
        Workspace,
        on_delete=models.CASCADE,
        related_name="data_assets",
    )
    data_source = models.ForeignKey(
        DataSource,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="assets",
    )
    name = models.CharField(max_length=180)
    asset_type = models.CharField(max_length=40, choices=AssetType.choices)
    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        default=Status.ACTIVE,
    )

    physical_schema = models.CharField(max_length=180, blank=True)
    physical_name = models.CharField(max_length=180, blank=True)
    metadata = models.JSONField(default=dict, blank=True)

    version = models.PositiveBigIntegerField(default=1)

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="data_assets_created",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(
                fields=["workspace", "name", "asset_type"],
                name="unique_asset_name_type_per_workspace",
            )
        ]

    def __str__(self):
        return f"{self.name} ({self.asset_type})"
