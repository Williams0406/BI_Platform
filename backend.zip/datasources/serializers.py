from rest_framework import serializers

from workspaces.models import Membership

from .models import DataAsset, DataSource



SECRET_KEYS = {
    "password",
    "pwd",
    "secret",
    "token",
    "access_token",
    "private_key",
}


def reject_persisted_secrets(metadata):
    lowered = {str(key).lower() for key in (metadata or {}).keys()}
    forbidden = sorted(lowered.intersection(SECRET_KEYS))
    if forbidden:
        raise serializers.ValidationError(
            "connection_metadata no puede almacenar secretos en esta fase: "
            + ", ".join(forbidden)
        )
    return metadata


WRITE_ROLES = [
    Membership.Role.OWNER,
    Membership.Role.ADMIN,
    Membership.Role.BUILDER,
]


def assert_workspace_write_access(request, workspace):
    allowed = Membership.objects.filter(
        organization=workspace.organization,
        user=request.user,
        is_active=True,
        role__in=WRITE_ROLES,
    ).exists()

    if not allowed:
        raise serializers.ValidationError(
            "No tiene permisos de escritura sobre este workspace."
        )


class DataSourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataSource
        fields = [
            "id",
            "workspace",
            "name",
            "mode",
            "engine",
            "status",
            "can_read",
            "can_write",
            "can_ddl",
            "connection_metadata",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["id", "created_at", "updated_at"]

    def validate_workspace(self, workspace):
        assert_workspace_write_access(self.context["request"], workspace)
        return workspace

    def validate_connection_metadata(self, value):
        return reject_persisted_secrets(value)

    def validate(self, attrs):
        mode = attrs.get("mode", getattr(self.instance, "mode", None))
        engine = attrs.get("engine", getattr(self.instance, "engine", None))

        if mode == DataSource.Mode.MANAGED and engine != DataSource.Engine.PLATFORM_POSTGRES:
            raise serializers.ValidationError(
                {
                    "engine": (
                        "Un DataSource MANAGED debe usar PLATFORM_POSTGRES "
                        "en esta versión."
                    )
                }
            )
        return attrs

    def create(self, validated_data):
        validated_data["created_by"] = self.context["request"].user
        return super().create(validated_data)


class DataAssetSerializer(serializers.ModelSerializer):
    data_source_name = serializers.CharField(
        source="data_source.name",
        read_only=True,
    )

    class Meta:
        model = DataAsset
        fields = [
            "id",
            "workspace",
            "data_source",
            "data_source_name",
            "name",
            "asset_type",
            "status",
            "physical_schema",
            "physical_name",
            "metadata",
            "version",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["id", "version", "created_at", "updated_at"]

    def validate_workspace(self, workspace):
        assert_workspace_write_access(self.context["request"], workspace)
        return workspace

    def validate(self, attrs):
        workspace = attrs.get("workspace", getattr(self.instance, "workspace", None))
        data_source = attrs.get(
            "data_source",
            getattr(self.instance, "data_source", None),
        )

        if data_source and workspace and data_source.workspace_id != workspace.id:
            raise serializers.ValidationError(
                {"data_source": "El DataSource pertenece a otro workspace."}
            )
        return attrs

    def create(self, validated_data):
        validated_data["created_by"] = self.context["request"].user
        return super().create(validated_data)
