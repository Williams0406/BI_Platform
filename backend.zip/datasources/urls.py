from rest_framework.routers import DefaultRouter

from .views import DataAssetViewSet, DataSourceViewSet

router = DefaultRouter()
router.register("sources", DataSourceViewSet, basename="data-source")
router.register("assets", DataAssetViewSet, basename="data-asset")

urlpatterns = router.urls
