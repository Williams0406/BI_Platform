from rest_framework import permissions, status, viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

from connectors.exceptions import ConnectorError
from connectors.permissions import user_can_manage_datasource
from connectors.serializers import CatalogRequestSerializer
from connectors.views import get_accessible_source, secret_free_validated_data

from .models import RelationAsset, TableAsset
from .serializers import RelationAssetSerializer, TableAssetSerializer
from .services import sync_catalog


class CatalogTableViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = TableAssetSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        queryset = (
            TableAsset.objects.filter(
                data_source__workspace__organization__memberships__user=self.request.user,
                data_source__workspace__organization__memberships__is_active=True,
            )
            .select_related("data_asset", "data_source")
            .prefetch_related("fields")
            .distinct()
        )

        source_id = self.request.query_params.get("data_source")
        if source_id:
            queryset = queryset.filter(data_source_id=source_id)

        schema = self.request.query_params.get("schema")
        if schema:
            queryset = queryset.filter(schema_name=schema)

        return queryset


class CatalogRelationViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = RelationAssetSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        queryset = (
            RelationAsset.objects.filter(
                data_source__workspace__organization__memberships__user=self.request.user,
                data_source__workspace__organization__memberships__is_active=True,
            )
            .select_related("data_source", "source_table", "target_table")
            .distinct()
        )

        source_id = self.request.query_params.get("data_source")
        if source_id:
            queryset = queryset.filter(data_source_id=source_id)

        return queryset


class CatalogSyncView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        data_source = get_accessible_source(request.user, pk)
        if not data_source:
            return Response(status=status.HTTP_404_NOT_FOUND)

        if not user_can_manage_datasource(request.user, data_source):
            return Response(
                {"detail": "No tiene permisos para sincronizar esta fuente."},
                status=status.HTTP_403_FORBIDDEN,
            )

        serializer = CatalogRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        runtime = secret_free_validated_data(data)

        try:
            result = sync_catalog(
                data_source=data_source,
                runtime_credentials=runtime,
                schemas=data.get("schemas"),
                include_views=data.get("include_views", True),
                created_by=request.user,
            )
        except ConnectorError as exc:
            return Response(
                {"detail": str(exc)},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(
            {
                "data_source": str(data_source.id),
                "result": result.to_dict(),
            }
        )
