from rest_framework import serializers

from .models import FieldAsset, RelationAsset, TableAsset


class FieldAssetSerializer(serializers.ModelSerializer):
    class Meta:
        model = FieldAsset
        fields = [
            "id",
            "name",
            "business_name",
            "description",
            "logical_type",
            "native_type",
            "ordinal_position",
            "nullable",
            "default_value",
            "max_length",
            "numeric_precision",
            "numeric_scale",
            "is_primary_key",
            "is_identity",
        ]


class TableAssetSerializer(serializers.ModelSerializer):
    fields = FieldAssetSerializer(many=True, read_only=True)

    class Meta:
        model = TableAsset
        fields = [
            "id",
            "data_asset",
            "data_source",
            "schema_name",
            "table_name",
            "object_type",
            "primary_key_columns",
            "row_version_column",
            "discovered_at",
            "last_synced_at",
            "fields",
        ]


class RelationAssetSerializer(serializers.ModelSerializer):
    source = serializers.SerializerMethodField()
    target = serializers.SerializerMethodField()

    class Meta:
        model = RelationAsset
        fields = [
            "id",
            "name",
            "data_source",
            "source_table",
            "target_table",
            "source",
            "target",
            "source_columns",
            "target_columns",
            "discovered_at",
            "last_synced_at",
        ]

    def get_source(self, obj):
        return f"{obj.source_table.schema_name}.{obj.source_table.table_name}"

    def get_target(self, obj):
        return f"{obj.target_table.schema_name}.{obj.target_table.table_name}"
