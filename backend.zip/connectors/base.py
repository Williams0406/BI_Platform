from abc import ABC, abstractmethod
from contextlib import contextmanager
from typing import Any, Iterable

from .exceptions import ConnectorConfigurationError
from .types import ColumnInfo, ForeignKeyInfo, TableInfo


class BaseConnector(ABC):
    """
    Common contract used by the rest of the platform.

    Connector implementations are responsible for:
    - connection validation
    - schema/table introspection
    - type normalization
    - safe read operations
    - engine-specific identifier quoting

    Credentials are provided at runtime. They are not persisted by this layer.
    """

    engine: str = ""
    required_config_fields: tuple[str, ...] = ()

    def __init__(self, config: dict[str, Any]):
        self.config = dict(config or {})
        self._validate_config()

    def _validate_config(self):
        missing = [
            field
            for field in self.required_config_fields
            if self.config.get(field) in (None, "")
        ]
        if missing:
            raise ConnectorConfigurationError(
                f"Faltan parámetros obligatorios: {', '.join(missing)}"
            )

    @abstractmethod
    @contextmanager
    def connection(self):
        yield

    @abstractmethod
    def quote_identifier(self, identifier: str) -> str:
        raise NotImplementedError

    @abstractmethod
    def test_connection(self) -> dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    def list_schemas(self) -> list[str]:
        raise NotImplementedError

    @abstractmethod
    def list_tables(self, schemas: list[str] | None = None) -> list[dict[str, Any]]:
        raise NotImplementedError

    @abstractmethod
    def get_columns(self, schema: str, table: str) -> list[ColumnInfo]:
        raise NotImplementedError

    @abstractmethod
    def get_primary_key(self, schema: str, table: str) -> list[str]:
        raise NotImplementedError

    @abstractmethod
    def get_foreign_keys(self, schema: str, table: str) -> list[ForeignKeyInfo]:
        raise NotImplementedError

    def introspect_table(self, schema: str, table: str, table_type: str = "TABLE") -> TableInfo:
        return TableInfo(
            schema=schema,
            name=table,
            table_type=table_type,
            columns=self.get_columns(schema, table),
            primary_key=self.get_primary_key(schema, table),
            foreign_keys=self.get_foreign_keys(schema, table),
        )

    def introspect_catalog(
        self,
        schemas: list[str] | None = None,
        include_views: bool = True,
    ) -> list[TableInfo]:
        tables = self.list_tables(schemas=schemas)
        if not include_views:
            tables = [item for item in tables if item["table_type"] == "TABLE"]

        return [
            self.introspect_table(
                item["schema"],
                item["name"],
                item.get("table_type", "TABLE"),
            )
            for item in tables
        ]

    @abstractmethod
    def read_page(
        self,
        schema: str,
        table: str,
        columns: list[str] | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        raise NotImplementedError

    @staticmethod
    def normalize_limit(limit: int, maximum: int = 1000) -> int:
        return max(1, min(int(limit), maximum))

    @staticmethod
    def normalize_offset(offset: int) -> int:
        return max(0, int(offset))
