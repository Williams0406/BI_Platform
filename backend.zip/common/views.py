import logging

from django.conf import settings
from django.core.cache import cache
from django.db import connection
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

logger = logging.getLogger("platform.health")


@api_view(["GET"])
@permission_classes([AllowAny])
def root(request):
    return Response(
        {
            "service": "business-intelligence-platform-api",
            "status": "ok",
            "api_version": "v1",
        }
    )


@api_view(["GET"])
@permission_classes([AllowAny])
def health_live(request):
    return Response({"status": "ok", "service": "api", "check": "liveness"})


@api_view(["GET"])
@permission_classes([AllowAny])
def health_ready(request):
    checks = {}
    ok = True

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
        checks["database"] = "available"
    except Exception as exc:
        logger.exception("Readiness database check failed")
        checks["database"] = exc.__class__.__name__
        ok = False

    if settings.OPS_READY_CHECK_REDIS:
        try:
            cache.set("health:ready", "ok", 5)
            if cache.get("health:ready") != "ok":
                raise RuntimeError("cache roundtrip failed")
            checks["redis"] = "available"
        except Exception as exc:
            checks["redis"] = exc.__class__.__name__
            ok = False

    if settings.OPS_READY_CHECK_STORAGE:
        try:
            from platform_ops.storage import healthcheck
            result = healthcheck()
            checks["storage"] = result
            if not result.get("ok"):
                ok = False
        except Exception as exc:
            checks["storage"] = {"ok": False, "detail": exc.__class__.__name__}
            ok = False

    return Response(
        {"status": "ok" if ok else "error", "checks": checks},
        status=status.HTTP_200_OK if ok else status.HTTP_503_SERVICE_UNAVAILABLE,
    )
