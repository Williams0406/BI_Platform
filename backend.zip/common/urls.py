from django.urls import path

from .views import health_live, health_ready, root

app_name = "common"

urlpatterns = [
    path("", root, name="root"),
    path("health/live/", health_live, name="health-live"),
    path("health/ready/", health_ready, name="health-ready"),
]
