import re
from typing import Any

from django.core.cache import cache
from django.db import connection

from .models import MetricDefinition, SemanticDimension


SQL_EXPR_FORBIDDEN = re.compile(
    r"\b(SELECT|FROM|JOIN|INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|GRANT|REVOKE)\b",
    re.IGNORECASE,
)


class MetricQueryError(ValueError):
    pass


def quote(identifier):
    return connection.ops.quote_name(identifier)


def _allowed_fields(metric):
    return {
        field.name: field
        for field in metric.semantic_model.base_table.fields.all()
    }


def _validate_sql_expression(metric, expression):
    if not expression.strip():
        raise MetricQueryError("La expresión SQL está vacía.")

    if ";" in expression:
        raise MetricQueryError("No se permiten múltiples sentencias.")

    if SQL_EXPR_FORBIDDEN.search(expression):
        raise MetricQueryError(
            "La expresión SQL de una métrica no puede contener sentencias completas."
        )

    fields = _allowed_fields(metric)
    for token in re.findall(r"\{\{field:([A-Za-z_][A-Za-z0-9_]*)\}\}", expression):
        if token not in fields:
            raise MetricQueryError(f"Campo no permitido en expresión: {token}")

    return expression


def render_metric_expression(metric):
    table = metric.semantic_model.base_table

    if metric.expression_type == MetricDefinition.ExpressionType.SIMPLE:
        if metric.aggregation == MetricDefinition.Aggregation.COUNT:
            return "COUNT(*)"

        if not metric.source_field:
            raise MetricQueryError(
                "La métrica SIMPLE requiere source_field excepto COUNT."
            )

        if metric.source_field.table_asset_id != table.id:
            raise MetricQueryError(
                "source_field no pertenece a la tabla base del SemanticModel."
            )

        field_sql = quote(metric.source_field.name)

        mapping = {
            MetricDefinition.Aggregation.SUM: f"SUM({field_sql})",
            MetricDefinition.Aggregation.AVG: f"AVG({field_sql})",
            MetricDefinition.Aggregation.MIN: f"MIN({field_sql})",
            MetricDefinition.Aggregation.MAX: f"MAX({field_sql})",
            MetricDefinition.Aggregation.COUNT_DISTINCT: f"COUNT(DISTINCT {field_sql})",
            MetricDefinition.Aggregation.NONE: field_sql,
        }
        if metric.aggregation not in mapping:
            raise MetricQueryError(
                f"Agregación no válida para SIMPLE: {metric.aggregation}"
            )
        return mapping[metric.aggregation]

    expression = _validate_sql_expression(metric, metric.expression)
    fields = _allowed_fields(metric)

    def replace(match):
        name = match.group(1)
        if name not in fields:
            raise MetricQueryError(f"Campo desconocido: {name}")
        return quote(name)

    return re.sub(
        r"\{\{field:([A-Za-z_][A-Za-z0-9_]*)\}\}",
        replace,
        expression,
    )


def validate_dimensions(metric, dimension_ids):
    if not dimension_ids:
        return []

    dimensions = list(
        SemanticDimension.objects.filter(
            id__in=dimension_ids,
            semantic_model=metric.semantic_model,
        ).select_related("field")
    )

    found = {str(item.id) for item in dimensions}
    missing = [value for value in dimension_ids if str(value) not in found]
    if missing:
        raise MetricQueryError(
            "Dimensiones inválidas para la métrica: " + ", ".join(map(str, missing))
        )

    return dimensions


def _build_filters(metric, filters):
    if not filters:
        return [], []

    fields = _allowed_fields(metric)
    clauses = []
    params = []

    operators = {
        "eq": "=",
        "ne": "<>",
        "gt": ">",
        "gte": ">=",
        "lt": "<",
        "lte": "<=",
        "contains": "ILIKE",
        "in": "IN",
    }

    for item in filters:
        field_name = item.get("field")
        operator = item.get("operator", "eq")
        value = item.get("value")

        if field_name not in fields:
            raise MetricQueryError(f"Filtro usa campo desconocido: {field_name}")
        if operator not in operators:
            raise MetricQueryError(f"Operador de filtro inválido: {operator}")

        if operator == "contains":
            clauses.append(f"{quote(field_name)} ILIKE %s")
            params.append(f"%{value}%")
        elif operator == "in":
            if not isinstance(value, list) or not value:
                raise MetricQueryError("El operador IN requiere una lista no vacía.")
            placeholders = ", ".join(["%s"] * len(value))
            clauses.append(f"{quote(field_name)} IN ({placeholders})")
            params.extend(value)
        else:
            clauses.append(f"{quote(field_name)} {operators[operator]} %s")
            params.append(value)

    return clauses, params


def _cache_key(metric, dimension_ids, filters, limit):
    payload = repr((str(metric.id), tuple(map(str, dimension_ids or [])), filters or [], limit))
    return f"metric-query:{hash(payload)}"


def execute_metric(metric, dimension_ids=None, filters=None, limit=1000, use_cache=True):
    if not metric.enabled:
        raise MetricQueryError("La métrica está deshabilitada.")

    key = _cache_key(metric, dimension_ids, filters, limit)
    if use_cache:
        cached = cache.get(key)
        if cached is not None:
            return {**cached, "cached": True}

    expression = render_metric_expression(metric)
    dimensions = validate_dimensions(metric, dimension_ids or [])

    select_parts = []
    group_parts = []

    for dimension in dimensions:
        field_sql = quote(dimension.field.name)
        select_parts.append(
            f"{field_sql} AS {quote(str(dimension.id))}"
        )
        group_parts.append(field_sql)

    select_parts.append(f"{expression} AS {quote('value')}")

    table = metric.semantic_model.base_table
    query = (
        f"SELECT {', '.join(select_parts)} "
        f"FROM {quote(table.schema_name)}.{quote(table.table_name)}"
    )

    where_clauses, params = _build_filters(metric, filters)
    if where_clauses:
        query += " WHERE " + " AND ".join(where_clauses)

    if group_parts:
        query += " GROUP BY " + ", ".join(group_parts)
        query += " ORDER BY " + ", ".join(group_parts)

    query += " LIMIT %s"
    params.append(min(max(int(limit), 1), 5000))

    with connection.cursor() as cursor:
        cursor.execute(query, params)
        names = [col[0] for col in cursor.description]
        rows = [dict(zip(names, row)) for row in cursor.fetchall()]

    result = {
        "metric": {
            "id": str(metric.id),
            "name": metric.name,
            "format_type": metric.format_type,
            "unit": metric.unit,
            "decimal_places": metric.decimal_places,
        },
        "dimensions": [
            {
                "id": str(d.id),
                "name": d.name,
                "field": d.field.name,
                "dimension_type": d.dimension_type,
            }
            for d in dimensions
        ],
        "rows": rows,
        "returned": len(rows),
        "cached": False,
    }

    if use_cache:
        cache.set(key, result, timeout=metric.cache_ttl_seconds)

    return result
