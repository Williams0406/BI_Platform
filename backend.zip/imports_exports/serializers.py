from rest_framework import serializers
from workspaces.models import Membership
from governance.services import get_quota
from .models import ExportJob,ImportJob

WRITE_ROLES={Membership.Role.OWNER,Membership.Role.ADMIN,Membership.Role.BUILDER}

def can_write(user,workspace):
    return Membership.objects.filter(organization=workspace.organization,user=user,is_active=True,role__in=WRITE_ROLES).exists()

class ImportJobSerializer(serializers.ModelSerializer):
    class Meta:
        model=ImportJob
        fields=["id","workspace","target_table","file","file_type","sheet_name","mode","column_mapping","status","execution_id","rows_total","rows_valid","rows_imported","rows_failed","error_report","created_at","finished_at"]
        read_only_fields=["id","status","execution_id","rows_total","rows_valid","rows_imported","rows_failed","error_report","created_at","finished_at"]
    def validate(self,attrs):
        ws=attrs["workspace"];table=attrs["target_table"]
        if table.data_source.workspace_id!=ws.id:raise serializers.ValidationError("Tabla y workspace no coinciden.")
        if not can_write(self.context["request"].user,ws):raise serializers.ValidationError("Sin permisos de importación.")
        return attrs
    def create(self,validated_data):
        return ImportJob.objects.create(created_by=self.context["request"].user,**validated_data)

class ExportJobSerializer(serializers.ModelSerializer):
    download_url=serializers.SerializerMethodField()
    class Meta:
        model=ExportJob
        fields=["id","workspace","source_table","file_type","columns","filters","row_limit","output_file","download_url","status","execution_id","rows_exported","created_at","finished_at","error_message"]
        read_only_fields=["id","output_file","download_url","status","execution_id","rows_exported","created_at","finished_at","error_message"]
    def get_download_url(self,obj):
        return obj.output_file.url if obj.output_file else None
    def validate(self,attrs):
        ws=attrs["workspace"];table=attrs["source_table"]
        if table.data_source.workspace_id!=ws.id:raise serializers.ValidationError("Tabla y workspace no coinciden.")
        if not can_write(self.context["request"].user,ws):raise serializers.ValidationError("Sin permisos de exportación.")
        quota=get_quota(ws)
        if attrs.get("row_limit",100000)>quota.max_export_rows:raise serializers.ValidationError("row_limit supera la cuota.")
        return attrs
    def create(self,validated_data):
        return ExportJob.objects.create(created_by=self.context["request"].user,**validated_data)
