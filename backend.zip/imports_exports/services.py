import csv
from pathlib import Path
from django.conf import settings
from django.core.files import File
from django.db import connection,transaction
from django.utils import timezone
from openpyxl import Workbook,load_workbook
from data_records.validators import validate_record_payload
from dependencies.services import record_change
from dependencies.tasks import propagate_asset_change_task
from governance.services import add_usage,assert_export_rows,assert_import_rows,audit
from .models import ExportJob,ImportJob

def quote(name): return connection.ops.quote_name(name)

def _read_rows(job):
    path=Path(job.file.path)
    if job.file_type==ImportJob.FileType.CSV:
        with path.open("r",encoding="utf-8-sig",newline="") as fh:
            reader=csv.DictReader(fh)
            for row in reader: yield row
    else:
        wb=load_workbook(path,read_only=True,data_only=True)
        ws=wb[job.sheet_name] if job.sheet_name else wb.active
        rows=ws.iter_rows(values_only=True)
        headers=[str(v) if v is not None else "" for v in next(rows)]
        for values in rows:
            yield {headers[i]:values[i] for i in range(len(headers))}

def preview_import(job,limit=50):
    rows=[]
    for i,row in enumerate(_read_rows(job)):
        if i>=limit:break
        rows.append(row)
    return rows

def _mapped(row,mapping):
    if not mapping:return dict(row)
    return {target:row.get(source) for source,target in mapping.items() if target}

@transaction.atomic
def execute_import(job,execution):
    from execution.services import mark_running,mark_success,update_progress
    mark_running(execution);job.status=ImportJob.Status.RUNNING;job.save(update_fields=["status"])
    table=job.target_table
    if table.data_source.mode!="MANAGED": raise ValueError("Fase 10 importa directamente solo sobre tablas MANAGED.")
    rows=list(_read_rows(job));job.rows_total=len(rows);assert_import_rows(job.workspace,len(rows))
    valid=[];errors=[]
    for idx,row in enumerate(rows,start=2):
        try: valid.append(validate_record_payload(table,_mapped(row,job.column_mapping),partial=False))
        except Exception as exc: errors.append({"row":idx,"error":str(exc)})
    job.rows_valid=len(valid);job.rows_failed=len(errors);job.error_report=errors[:1000];job.save(update_fields=["rows_total","rows_valid","rows_failed","error_report"])
    update_progress(execution,30,"Validación de archivo completada.")
    if errors:
        raise ValueError(f"Importación detenida: {len(errors)} filas inválidas.")
    if not valid:
        raise ValueError("El archivo no contiene filas válidas.")
    fields=list(valid[0])
    cols=", ".join(quote(f) for f in fields)
    placeholders=", ".join(["%s"]*len(fields))
    pk=list(table.primary_key_columns or [])
    if job.mode==ImportJob.Mode.UPSERT:
        if len(pk)!=1: raise ValueError("UPSERT requiere PK simple.")
        update_fields=[f for f in fields if f!=pk[0]]
        if update_fields:
            conflict=f" ON CONFLICT ({quote(pk[0])}) DO UPDATE SET "+", ".join(f"{quote(f)}=EXCLUDED.{quote(f)}" for f in update_fields)
        else:
            conflict=f" ON CONFLICT ({quote(pk[0])}) DO NOTHING"
    else: conflict=""
    sql=f"INSERT INTO {quote(table.schema_name)}.{quote(table.table_name)} ({cols}) VALUES ({placeholders}){conflict}"
    chunk=settings.IMPORT_EXPORT_CHUNK_SIZE
    with connection.cursor() as cursor:
        for start in range(0,len(valid),chunk):
            batch=valid[start:start+chunk]
            cursor.executemany(sql,[[row.get(f) for f in fields] for row in batch])
            update_progress(execution,30+int(60*(start+len(batch))/len(valid)))
    job.rows_imported=len(valid);job.status=ImportJob.Status.SUCCESS;job.finished_at=timezone.now();job.save(update_fields=["rows_imported","status","finished_at"])
    event=record_change(table.data_asset,"REFRESH",user=job.created_by,metadata={"import_job_id":str(job.id),"rows":len(valid)})
    transaction.on_commit(lambda: propagate_asset_change_task.apply_async(args=[str(event.id)],queue="fast"))
    size=Path(job.file.path).stat().st_size if Path(job.file.path).exists() else 0
    add_usage(job.workspace,storage_bytes=size,import_rows=len(valid),executions=1)
    audit(job.workspace,"IMPORT_SUCCESS","ImportJob",job.id,job.created_by,{"rows":len(valid),"table":str(table.id)})
    result={"import_job_id":str(job.id),"rows_imported":len(valid),"change_event_id":str(event.id)}
    mark_success(execution,result);return result

def _export_query(job):
    table=job.source_table
    allowed=set(table.fields.values_list("name",flat=True))
    columns=job.columns or list(allowed)
    unknown=set(columns)-allowed
    if unknown: raise ValueError("Columnas desconocidas: "+", ".join(sorted(unknown)))
    clauses=[];params=[]
    ops={"eq":"=","ne":"<>","gt":">","gte":">=","lt":"<","lte":"<="}
    for item in job.filters or []:
        field=item.get("field");op=item.get("operator","eq");value=item.get("value")
        if field not in allowed or op not in ops: raise ValueError("Filtro inválido.")
        clauses.append(f"{quote(field)} {ops[op]} %s");params.append(value)
    query=f"SELECT {', '.join(quote(c) for c in columns)} FROM {quote(table.schema_name)}.{quote(table.table_name)}"
    if clauses:query+=" WHERE "+" AND ".join(clauses)
    query+=" LIMIT %s";params.append(job.row_limit)
    return query,params,columns

def execute_export(job,execution):
    from execution.services import mark_running,mark_success,update_progress
    mark_running(execution);job.status=ExportJob.Status.RUNNING;job.save(update_fields=["status"])
    if job.source_table.data_source.mode!="MANAGED": raise ValueError("Export directo de Fase 10 requiere tabla MANAGED.")
    assert_export_rows(job.workspace,job.row_limit)
    query,params,columns=_export_query(job)
    with connection.cursor() as cursor:
        cursor.execute(query,params);rows=cursor.fetchall()
    assert_export_rows(job.workspace,len(rows));update_progress(execution,50,"Datos consultados.")
    root=Path(settings.MEDIA_ROOT)/"exports"/str(job.workspace_id);root.mkdir(parents=True,exist_ok=True)
    suffix=".csv" if job.file_type==ExportJob.FileType.CSV else ".xlsx"
    path=root/f"{job.id}{suffix}"
    if job.file_type==ExportJob.FileType.CSV:
        with path.open("w",encoding="utf-8-sig",newline="") as fh:
            writer=csv.writer(fh);writer.writerow(columns);writer.writerows(rows)
    else:
        wb=Workbook(write_only=True);ws=wb.create_sheet("Data");ws.append(columns)
        for row in rows:ws.append(list(row))
        wb.save(path)
    with path.open("rb") as fh:
        job.output_file.save(path.name,File(fh),save=False)
    job.rows_exported=len(rows);job.status=ExportJob.Status.SUCCESS;job.finished_at=timezone.now();job.save(update_fields=["output_file","rows_exported","status","finished_at"])
    add_usage(job.workspace,storage_bytes=path.stat().st_size,export_rows=len(rows),executions=1)
    audit(job.workspace,"EXPORT_SUCCESS","ExportJob",job.id,job.created_by,{"rows":len(rows),"table":str(job.source_table_id)})
    result={"export_job_id":str(job.id),"rows_exported":len(rows),"file":job.output_file.name}
    mark_success(execution,result);return result
