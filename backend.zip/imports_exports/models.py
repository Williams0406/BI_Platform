import uuid
from django.conf import settings
from django.db import models
from data_model.models import TableAsset
from workspaces.models import Workspace

class ImportJob(models.Model):
    class FileType(models.TextChoices):
        CSV="CSV","CSV"
        XLSX="XLSX","Excel"
    class Mode(models.TextChoices):
        APPEND="APPEND","Append"
        UPSERT="UPSERT","Upsert"
    class Status(models.TextChoices):
        UPLOADED="UPLOADED","Uploaded"
        QUEUED="QUEUED","Queued"
        RUNNING="RUNNING","Running"
        SUCCESS="SUCCESS","Success"
        FAILED="FAILED","Failed"
    id=models.UUIDField(primary_key=True,default=uuid.uuid4,editable=False)
    workspace=models.ForeignKey(Workspace,on_delete=models.CASCADE,related_name="import_jobs")
    target_table=models.ForeignKey(TableAsset,on_delete=models.CASCADE,related_name="import_jobs")
    file=models.FileField(upload_to="imports/%Y/%m/%d/")
    file_type=models.CharField(max_length=10,choices=FileType.choices)
    sheet_name=models.CharField(max_length=180,blank=True)
    mode=models.CharField(max_length=10,choices=Mode.choices,default=Mode.APPEND)
    column_mapping=models.JSONField(default=dict,blank=True)
    status=models.CharField(max_length=20,choices=Status.choices,default=Status.UPLOADED)
    execution_id=models.UUIDField(null=True,blank=True)
    rows_total=models.PositiveBigIntegerField(default=0)
    rows_valid=models.PositiveBigIntegerField(default=0)
    rows_imported=models.PositiveBigIntegerField(default=0)
    rows_failed=models.PositiveBigIntegerField(default=0)
    error_report=models.JSONField(default=list,blank=True)
    created_by=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name="import_jobs_created")
    created_at=models.DateTimeField(auto_now_add=True)
    finished_at=models.DateTimeField(null=True,blank=True)
    class Meta: ordering=["-created_at"]

class ExportJob(models.Model):
    class FileType(models.TextChoices):
        CSV="CSV","CSV"
        XLSX="XLSX","Excel"
    class Status(models.TextChoices):
        QUEUED="QUEUED","Queued"
        RUNNING="RUNNING","Running"
        SUCCESS="SUCCESS","Success"
        FAILED="FAILED","Failed"
    id=models.UUIDField(primary_key=True,default=uuid.uuid4,editable=False)
    workspace=models.ForeignKey(Workspace,on_delete=models.CASCADE,related_name="export_jobs")
    source_table=models.ForeignKey(TableAsset,on_delete=models.CASCADE,related_name="export_jobs")
    file_type=models.CharField(max_length=10,choices=FileType.choices)
    columns=models.JSONField(default=list,blank=True)
    filters=models.JSONField(default=list,blank=True)
    row_limit=models.PositiveBigIntegerField(default=100000)
    output_file=models.FileField(upload_to="exports/%Y/%m/%d/",blank=True)
    status=models.CharField(max_length=20,choices=Status.choices,default=Status.QUEUED)
    execution_id=models.UUIDField(null=True,blank=True)
    rows_exported=models.PositiveBigIntegerField(default=0)
    created_by=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name="export_jobs_created")
    created_at=models.DateTimeField(auto_now_add=True)
    finished_at=models.DateTimeField(null=True,blank=True)
    error_message=models.TextField(blank=True)
    class Meta: ordering=["-created_at"]
