from celery import shared_task
from execution.models import Execution
from execution.services import mark_failed
from django.utils import timezone
from .models import ExportJob,ImportJob
from .services import execute_export,execute_import

@shared_task(bind=True,name="imports_exports.tasks.run_import_task")
def run_import_task(self,execution_id,job_id):
    execution=Execution.objects.get(id=execution_id);job=ImportJob.objects.select_related("workspace","target_table","target_table__data_source","target_table__data_asset","created_by").get(id=job_id)
    execution.celery_task_id=self.request.id or "";execution.save(update_fields=["celery_task_id"])
    try:return execute_import(job,execution)
    except Exception as exc:
        job.status=ImportJob.Status.FAILED;job.finished_at=timezone.now();job.error_report=(job.error_report or [])+[{"error":str(exc)}];job.save(update_fields=["status","finished_at","error_report"])
        mark_failed(execution,exc);raise

@shared_task(bind=True,name="imports_exports.tasks.run_export_task")
def run_export_task(self,execution_id,job_id):
    execution=Execution.objects.get(id=execution_id);job=ExportJob.objects.select_related("workspace","source_table","source_table__data_source","created_by").get(id=job_id)
    execution.celery_task_id=self.request.id or "";execution.save(update_fields=["celery_task_id"])
    try:return execute_export(job,execution)
    except Exception as exc:
        job.status=ExportJob.Status.FAILED;job.finished_at=timezone.now();job.error_message=str(exc);job.save(update_fields=["status","finished_at","error_message"])
        mark_failed(execution,exc);raise
