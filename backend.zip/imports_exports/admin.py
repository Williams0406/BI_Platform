from django.contrib import admin
from .models import ExportJob,ImportJob

@admin.register(ImportJob)
class ImportJobAdmin(admin.ModelAdmin):
    list_display=["id","workspace","target_table","file_type","mode","status","rows_imported","created_at"]
    list_filter=["file_type","mode","status"]

@admin.register(ExportJob)
class ExportJobAdmin(admin.ModelAdmin):
    list_display=["id","workspace","source_table","file_type","status","rows_exported","created_at"]
    list_filter=["file_type","status"]
