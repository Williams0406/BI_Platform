"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

import ManageTabs from "@/components/manage/ManageTabs";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import Spinner from "@/components/ui/Spinner";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { listGateways } from "@/lib/services/customerGateway";
import { getQuota, getRetention, getUsage } from "@/lib/services/governance";
import { getOperationalStatus } from "@/lib/services/operations";

const listValue = (data) => Array.isArray(data) ? data : data?.results || [];
const ADMIN = ["OWNER", "ADMIN"];

function roleName(role) {
  return { OWNER:"Owner", ADMIN:"Admin", BUILDER:"Builder", ANALYST:"Analyst", VIEWER:"Viewer" }[role] || role || "No role";
}
function mb(bytes){ return ((Number(bytes||0))/1048576).toFixed(1); }

export default function ManagePage() {
  const { activeWorkspace, organizations, workspaces } = useWorkspace();
  const [quota,setQuota]=useState(null),[usage,setUsage]=useState(null),[retention,setRetention]=useState(null),[gateways,setGateways]=useState([]);
  const [ops,setOps]=useState(null),[opsRestricted,setOpsRestricted]=useState(false),[loading,setLoading]=useState(true),[error,setError]=useState("");
  const organization = useMemo(() => organizations.find(x => x.id === activeWorkspace?.organization), [organizations, activeWorkspace]);
  const role = organization?.current_user_role;
  const canGovern = ADMIN.includes(role);

  useEffect(() => {
    let alive=true;
    async function load(){
      if(!activeWorkspace?.id){setLoading(false);return;}
      setLoading(true);setError("");setOpsRestricted(false);
      const [q,u,r,g,o]=await Promise.allSettled([
        getQuota(activeWorkspace.id),getUsage(activeWorkspace.id),getRetention(activeWorkspace.id),
        listGateways(activeWorkspace.id),
        getOperationalStatus(),
      ]);
      if(!alive)return;
      if(q.status==="fulfilled")setQuota(q.value);
      if(u.status==="fulfilled")setUsage(u.value);
      if(r.status==="fulfilled")setRetention(r.value);
      if(g.status==="fulfilled")setGateways(listValue(g.value));
      if(o.status==="fulfilled")setOps(o.value);
      else if(o.reason?.response?.status===403)setOpsRestricted(true);
      const coreFailure=[q,u,r,g].find(x=>x.status==="rejected");
      if(coreFailure)setError(coreFailure.reason?.response?.data?.detail || coreFailure.reason?.message || "Some management data could not be loaded.");
      setLoading(false);
    }
    load();
    return()=>{alive=false;};
  },[activeWorkspace?.id]);

  if(!activeWorkspace)return <EmptyState title="Select a workspace" description="Management settings are scoped to the active workspace." />;
  if(loading)return <Spinner label="Loading management overview..." />;

  const activeGateways=gateways.filter(g=>g.effective_status!=="REVOKED");
  const recentGateways=gateways.filter(g=>g.effective_status==="ONLINE" || g.effective_status==="ACTIVE");

  return <div className="pageStack">
    <header className="pageHeader"><div><p className="eyebrow">Manage</p><h1>Workspace administration</h1><p>Manage context, governance, private connectivity and platform health without navigating backend-oriented modules.</p></div></header>
    <ManageTabs />
    {error&&<Alert type="error">{error}</Alert>}

    <section className="manageContextHero">
      <div><small>ACTIVE WORKSPACE</small><strong>{activeWorkspace.name}</strong><span>{organization?.name || activeWorkspace.organization_name}</span></div>
      <div><small>YOUR ROLE</small><strong>{roleName(role)}</strong><span>{canGovern?"Can manage governance settings":"Workspace access is role-limited"}</span></div>
      <div><small>WORKSPACES</small><strong>{workspaces.filter(w=>w.organization===activeWorkspace.organization).length}</strong><span>In this organization</span></div>
      <div><small>PRIVATE GATEWAYS</small><strong>{activeGateways.length}</strong><span>{recentGateways.length} currently active / online</span></div>
    </section>

    <section className="manageAreaGrid">
      <Link className="manageAreaCard" href="/app/workspaces"><span className="manageAreaIcon">W</span><div><h2>Workspace</h2><p>Select and maintain operational workspaces and their organization context.</p></div><strong>Open →</strong></Link>
      <Link className="manageAreaCard" href="/app/organizations"><span className="manageAreaIcon">A</span><div><h2>Access context</h2><p>Review organizations and the role that determines what you can administer.</p></div><strong>Open →</strong></Link>
      <Link className="manageAreaCard" href="/app/governance"><span className="manageAreaIcon">G</span><div><h2>Governance</h2><p>Usage, quotas, retention, audit, explicit permissions, encrypted secrets and destructive approvals.</p></div><strong>Open →</strong></Link>
      <Link className="manageAreaCard" href="/app/customer-gateway"><span className="manageAreaIcon">P</span><div><h2>Private connections</h2><p>Operate outbound-only gateways while database credentials stay inside customer infrastructure.</p></div><strong>Open →</strong></Link>
      <Link className="manageAreaCard" href="/app/operations"><span className="manageAreaIcon">H</span><div><h2>Platform health</h2><p>Check liveness, readiness, workspace integration and privileged infrastructure telemetry.</p></div><strong>Open →</strong></Link>
      <Link className="manageAreaCard" href="/app/import-export"><span className="manageAreaIcon">↔</span><div><h2>Data movement</h2><p>Import and export governed datasets while respecting workspace quotas and audit controls.</p></div><strong>Open →</strong></Link>
    </section>

    <section className="manageSplit">
      <article className="card">
        <div className="cardHeader"><div><p className="eyebrow">Governance snapshot</p><h2>Usage & policy</h2></div><Link href="/app/governance">Manage →</Link></div>
        <div className="manageDefinitionList">
          <div><span>Storage</span><strong>{mb(usage?.storage_bytes)} MB / {quota?.max_storage_mb ?? "—"} MB</strong></div>
          <div><span>Executions started</span><strong>{usage?.executions_started ?? 0}</strong></div>
          <div><span>Concurrent jobs limit</span><strong>{quota?.max_concurrent_jobs ?? "—"}</strong></div>
          <div><span>Audit retention</span><strong>{retention?.audit_log_days ?? "—"} days</strong></div>
          <div><span>Execution retention</span><strong>{retention?.execution_log_days ?? "—"} days</strong></div>
        </div>
      </article>
      <article className="card">
        <div className="cardHeader"><div><p className="eyebrow">Platform boundary</p><h2>Administration levels</h2></div></div>
        <div className="manageBoundary">
          <div className={canGovern?"ok":""}><strong>Workspace governance</strong><span>{canGovern?"Available with your organization role.":"OWNER or ADMIN is required for policy changes."}</span></div>
          <div className={ops?"ok":opsRestricted?"restricted":""}><strong>Platform telemetry</strong><span>{ops?"Privileged telemetry is available.":opsRestricted?"Requires Django is_staff=True; OWNER/ADMIN does not grant platform staff access.":"Telemetry unavailable."}</span></div>
        </div>
      </article>
    </section>
  </div>;
}
