"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

import DataHubTabs from "@/components/data/DataHubTabs";
import EmptyState from "@/components/ui/EmptyState";
import Icon from "@/components/ui/Icon";
import Spinner from "@/components/ui/Spinner";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { listDataAssets, listDataSources } from "@/lib/services/dataSources";
import { getApiErrorMessage } from "@/lib/utils/errors";

const DATA_TYPES = new Set(["TABLE", "VIEW", "DERIVED_TABLE", "DATASET"]);

export default function DataHubPage() {
  const { activeWorkspace } = useWorkspace();
  const [sources, setSources] = useState([]);
  const [assets, setAssets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!activeWorkspace?.id) { setSources([]); setAssets([]); return; }
    let alive = true;
    (async () => {
      setLoading(true); setError("");
      try {
        const [nextSources, nextAssets] = await Promise.all([
          listDataSources(activeWorkspace.id),
          listDataAssets(activeWorkspace.id),
        ]);
        if (alive) { setSources(nextSources || []); setAssets(nextAssets || []); }
      } catch (requestError) { if (alive) setError(getApiErrorMessage(requestError)); }
      finally { if (alive) setLoading(false); }
    })();
    return () => { alive = false; };
  }, [activeWorkspace?.id]);

  const dataAssets = useMemo(() => assets.filter((asset) => DATA_TYPES.has(asset.asset_type)), [assets]);
  const healthySources = sources.filter((source) => ["ACTIVE", "READY", "CONNECTED"].includes(source.status)).length;
  const managed = sources.filter((source) => source.mode === "MANAGED").length;

  if (!activeWorkspace) return <EmptyState title="Select a workspace" description="Data Hub needs an active workspace before it can show sources and catalog content." />;

  return <div className="pageStack dataHubPage">
    <header className="pageHeader pageHeaderActions">
      <div><p className="eyebrow">Data</p><h1>Data Hub</h1><p>Connect, discover and understand the data available in <strong>{activeWorkspace.name}</strong>.</p></div>
      <div className="formActions"><Link className="button secondaryButton" href="/app/import-export">Import file</Link><Link className="button primaryButton" href="/app/data-sources">Connect data</Link></div>
    </header>
    <DataHubTabs />
    {error ? <div className="alert alert-error">{error}</div> : null}
    {loading ? <Spinner label="Loading data workspace..." /> : <>
      <section className="dataHubMetrics">
        <div><span>Sources</span><strong>{sources.length}</strong><small>{healthySources} active / ready</small></div>
        <div><span>Data objects</span><strong>{dataAssets.length}</strong><small>tables, views and datasets</small></div>
        <div><span>Managed sources</span><strong>{managed}</strong><small>platform controlled</small></div>
        <div><span>Workspace</span><strong className="truncateText">{activeWorkspace.name}</strong><small>active context</small></div>
      </section>

      <section className="dataHubSplit">
        <div className="dataHubPanel">
          <div className="sectionHeading"><div><p className="eyebrow">Catalog</p><h2>Recently available data</h2></div><Link href="/app/data-assets">Browse catalog</Link></div>
          {dataAssets.length === 0 ? <div className="dataHubInlineEmpty"><Icon name="catalog" size={24}/><strong>No data objects yet</strong><span>Connect or import data to populate your catalog.</span><Link href="/app/data-sources">Connect data</Link></div> : <div className="dataObjectList">
            {dataAssets.slice(0, 8).map((asset) => <Link href={`/app/data-assets/${asset.id}`} className="dataObjectRow" key={asset.id}>
              <span className="resourceIcon"><Icon name={asset.asset_type === "DATASET" ? "table" : "database"} size={17}/></span>
              <span className="dataObjectMain"><strong>{asset.name}</strong><small>{asset.data_source_name || "Generated asset"} · {asset.asset_type}</small></span>
              <span className={`statusBadge status-${asset.status}`}>{asset.status}</span>
            </Link>)}
          </div>}
        </div>

        <div className="dataHubPanel">
          <div className="sectionHeading"><div><p className="eyebrow">Sources</p><h2>Connections</h2></div><Link href="/app/data-sources">Manage</Link></div>
          {sources.length === 0 ? <div className="dataHubInlineEmpty compact"><Icon name="plug" size={24}/><strong>No connections</strong><span>Add your first source.</span></div> : <div className="sourceCompactList">
            {sources.slice(0, 6).map((source) => <Link href={`/app/data-sources/${source.id}`} key={source.id}>
              <span className="sourceModeIcon"><Icon name="database" size={16}/></span><span><strong>{source.name}</strong><small>{source.mode} · {source.engine}</small></span><i className={`sourceHealth sourceHealth-${String(source.status).toLowerCase()}`}/></Link>)}
          </div>}
        </div>
      </section>

      <section className="dataHubPanel">
        <div className="sectionHeading"><div><p className="eyebrow">Start here</p><h2>Common data workflows</h2></div></div>
        <div className="dataWorkflowGrid">
          <Link href="/app/data-sources"><Icon name="plug" size={19}/><div><strong>Connect a database</strong><span>PostgreSQL, SQL Server or Private Gateway.</span></div></Link>
          <Link href="/app/import-export"><Icon name="transfer" size={19}/><div><strong>Import CSV / Excel</strong><span>Load files into a managed table.</span></div></Link>
          <Link href="/app/data-model"><Icon name="model" size={19}/><div><strong>Review the model</strong><span>Inspect tables, fields and relationships.</span></div></Link>
          <Link href="/app/data-assets"><Icon name="catalog" size={19}/><div><strong>Browse the catalog</strong><span>Find reusable data across the workspace.</span></div></Link>
        </div>
      </section>
    </>}
  </div>;
}
