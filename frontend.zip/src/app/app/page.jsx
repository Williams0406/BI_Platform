"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import Icon from "@/components/ui/Icon";
import WorkspaceSetupGuide from "@/components/onboarding/WorkspaceSetupGuide";
import { useAuth } from "@/lib/hooks/useAuth";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { listDashboards } from "@/lib/services/analytics";
import { listDataAssets } from "@/lib/services/dataSources";
import { listExecutions } from "@/lib/services/executions";
import { listMetrics } from "@/lib/services/metrics";
import { executionLabel, executionTimestamp, formatRelativeTime, normalizeCollection } from "@/lib/utils/activity";
import { displayName } from "@/lib/utils/formatters";

const QUICK_ACTIONS = [
  ["Analyze data", "Explore tables and measures", "explore", "/app/analytics"],
  ["Build dashboard", "Turn insights into a shared view", "dashboard", "/app/dashboards"],
  ["Connect data", "PostgreSQL, SQL Server or private gateway", "plug", "/app/data-sources"],
  ["Prepare data", "Transform and organize reusable datasets", "transform", "/app/transformations"],
];

export default function AppHomePage() {
  const { user } = useAuth();
  const { organizations, workspaces, activeWorkspace, activeWorkspaceId, isLoading } = useWorkspace();
  const [dashboards, setDashboards] = useState([]);
  const [assets, setAssets] = useState([]);
  const [metrics, setMetrics] = useState([]);
  const [activity, setActivity] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!activeWorkspaceId) { setDashboards([]); setAssets([]); setMetrics([]); setActivity([]); return; }
    let mounted = true; setLoading(true);
    Promise.allSettled([listDashboards(activeWorkspaceId), listDataAssets(activeWorkspaceId), listMetrics(activeWorkspaceId), listExecutions({workspace:activeWorkspaceId})])
      .then(([d,a,m,e]) => {
        if (!mounted) return;
        setDashboards(d.status === "fulfilled" ? normalizeCollection(d.value).slice(0,4) : []);
        setAssets(a.status === "fulfilled" ? normalizeCollection(a.value).slice(0,5) : []);
        setMetrics(m.status === "fulfilled" ? normalizeCollection(m.value).slice(0,5) : []);
        setActivity(e.status === "fulfilled" ? normalizeCollection(e.value).slice(0,6) : []);
      }).finally(()=>mounted&&setLoading(false));
    return ()=>{mounted=false;};
  }, [activeWorkspaceId]);

  const firstName = useMemo(() => displayName(user)?.split(" ")[0] || "", [user]);
  const activeOrganization = useMemo(() => organizations.find((item) => item.id === activeWorkspace?.organization), [organizations, activeWorkspace]);
  const role = activeOrganization?.current_user_role;

  if (!isLoading && organizations.length === 0) return <div className="pageStack"><section className="homeHero"><p className="eyebrow">GET STARTED</p><h1>Welcome{firstName ? `, ${firstName}` : ""}</h1><p>Create an organization to establish your first analytics workspace.</p><Link className="button buttonPrimary linkButton" href="/app/organizations">Create organization</Link></section></div>;
  if (!isLoading && organizations.length > 0 && workspaces.length === 0) return <div className="pageStack"><section className="homeHero"><p className="eyebrow">GET STARTED</p><h1>Your organization is ready</h1><p>Create a workspace to connect data and start building analyses.</p><Link className="button buttonPrimary linkButton" href="/app/workspaces">Create workspace</Link></section></div>;

  return <div className="homePage">
    <section className="homeHero">
      <div><p className="eyebrow">{activeWorkspace?.name || "WORKSPACE"}</p><h1>Good to see you{firstName ? `, ${firstName}` : ""}.</h1><p>Continue your work or start from the outcome you need.</p></div>
      <div className="headerActions"><Link className="button buttonGhost linkButton" href="/app/get-started">Setup guide</Link><Link className="button buttonGhost linkButton" href="/app/executions"><Icon name="activity" size={16}/> View activity</Link></div>
    </section>

    <WorkspaceSetupGuide activeWorkspace={activeWorkspace} role={role}/>

    <section className="quickActionGrid">{(["OWNER","ADMIN","BUILDER"].includes(role) ? QUICK_ACTIONS : [
      ["Explore data", "Review available analyses and governed measures", "explore", "/app/analytics"],
      ["View dashboards", "Open shared decision views", "dashboard", "/app/dashboards"],
      ["Browse catalog", "Understand available governed data", "catalog", "/app/data-assets"],
      ["View activity", "See recent workspace processing", "activity", "/app/executions"],
    ]).map(([title,detail,icon,href])=><Link className="quickAction" href={href} key={title}><span className="quickActionIcon"><Icon name={icon} size={20}/></span><div><strong>{title}</strong><small>{detail}</small></div><span className="quickArrow">→</span></Link>)}</section>

    <div className="homeColumns">
      <section className="homeSection homeSectionWide">
        <div className="sectionHeading"><div><p className="eyebrow">CONTINUE WORKING</p><h2>Dashboards</h2></div><Link href="/app/dashboards">View all</Link></div>
        {loading ? <p className="homeEmpty">Loading…</p> : dashboards.length ? <div className="recentGrid">{dashboards.map((x)=><Link href={`/app/dashboards/${x.id}`} className="recentCard" key={x.id}><span className="resourceIcon"><Icon name="dashboard" size={18}/></span><div><strong>{x.name}</strong><small>Dashboard · {x.description || "Workspace analysis"}</small></div></Link>)}</div> : <div className="homeEmptyState"><Icon name="dashboard" size={24}/><strong>No dashboards yet</strong><span>{["OWNER","ADMIN","BUILDER"].includes(role) ? "Build your first shared decision view." : "No shared decision views are available yet."}</span>{["OWNER","ADMIN","BUILDER"].includes(role) ? <Link href="/app/dashboards">Create dashboard</Link> : <Link href="/app/data-assets">Browse catalog</Link>}</div>}
      </section>

      <section className="homeSection">
        <div className="sectionHeading"><div><p className="eyebrow">RECENT</p><h2>Activity</h2></div><Link href="/app/executions">View all</Link></div>
        <div className="homeActivityList">{activity.length ? activity.map(x=><Link href={`/app/executions/${x.id}`} key={x.id}><span className={`activityDot status-${String(x.status||"").toLowerCase()}`}/><div><strong>{executionLabel(x)}</strong><small>{x.status} · {formatRelativeTime(executionTimestamp(x))}</small></div></Link>) : <p className="homeEmpty">No recent activity.</p>}</div>
      </section>
    </div>

    <section className="homeSection">
      <div className="sectionHeading"><div><p className="eyebrow">WORKSPACE CONTENT</p><h2>Discover your data</h2></div><Link href="/app/data-assets">Open catalog</Link></div>
      <div className="contentSummaryGrid"><div><span>Data assets</span><strong>{assets.length}{assets.length===5?"+":""}</strong><small>Tables, datasets and analytical assets</small></div><div><span>Measures</span><strong>{metrics.length}{metrics.length===5?"+":""}</strong><small>Reusable business calculations</small></div><div><span>Workspace</span><strong>{activeWorkspace?.name || "—"}</strong><small>{activeWorkspace?.organization_name || "Current context"}</small></div></div>
    </section>
  </div>;
}
