"use client";

import Link from "next/link";
import { useMemo, useState } from "react";

import ManageTabs from "@/components/manage/ManageTabs";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import WorkspaceForm from "@/components/workspaces/WorkspaceForm";
import { ROUTES } from "@/lib/constants/routes";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import {
  createWorkspace,
  deleteWorkspace,
  updateWorkspace,
} from "@/lib/services/workspaces";
import { getApiErrorMessage } from "@/lib/utils/errors";

export default function WorkspacesPage() {
  const {
    organizations,
    workspaces,
    activeWorkspace,
    setActiveWorkspace,
    refresh,
    isLoading,
  } = useWorkspace();
  const [showCreate, setShowCreate] = useState(false);
  const [editing, setEditing] = useState(null);
  const [organizationFilter, setOrganizationFilter] = useState("ALL");
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });

  const visibleWorkspaces = useMemo(
    () =>
      organizationFilter === "ALL"
        ? workspaces
        : workspaces.filter((workspace) => workspace.organization === organizationFilter),
    [organizationFilter, workspaces],
  );

  function roleFor(workspace) {
    return organizations.find((organization) => organization.id === workspace.organization)
      ?.current_user_role;
  }

  async function handleCreate(payload) {
    setSubmitting(true);
    setMessage({ type: "", text: "" });
    try {
      const created = await createWorkspace(payload);
      await refresh();
      setActiveWorkspace(created);
      setShowCreate(false);
      setMessage({ type: "success", text: "Workspace creado y seleccionado como activo." });
    } catch (error) {
      setMessage({ type: "error", text: getApiErrorMessage(error) });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleUpdate(payload) {
    if (!editing) return;
    setSubmitting(true);
    setMessage({ type: "", text: "" });
    try {
      await updateWorkspace(editing.id, payload);
      await refresh();
      setEditing(null);
      setMessage({ type: "success", text: "Workspace actualizado correctamente." });
    } catch (error) {
      setMessage({ type: "error", text: getApiErrorMessage(error) });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(workspace) {
    if (!window.confirm(`¿Eliminar el workspace "${workspace.name}"?`)) return;
    setMessage({ type: "", text: "" });
    try {
      await deleteWorkspace(workspace.id);
      await refresh();
      setMessage({ type: "success", text: "Workspace eliminado." });
    } catch (error) {
      setMessage({ type: "error", text: getApiErrorMessage(error) });
    }
  }

  return (
    <div className="pageStack">
      <section className="pageHeader pageHeaderActions">
        <div>
          <p className="eyebrow">Manage · Workspace</p>
          <h1>Workspaces</h1>
          <p>
            Workspaces are the operating boundary for data, analytics, ML, optimization, governance and execution.
          </p>
        </div>
        <button
          type="button"
          className="button buttonPrimary"
          onClick={() => setShowCreate((value) => !value)}
          disabled={organizations.length === 0}
        >
          {showCreate ? "Cerrar formulario" : "Nuevo workspace"}
        </button>
      </section>

      <ManageTabs />

      {message.text ? <Alert type={message.type}>{message.text}</Alert> : null}

      {organizations.length === 0 ? (
        <Alert type="info">
          Primero necesitas una organización. <Link href={ROUTES.ORGANIZATIONS}>Ir a Organizations</Link>.
        </Alert>
      ) : null}

      {showCreate ? (
        <section className="card">
          <div className="cardHeader">
            <div>
              <p className="eyebrow">CREATE</p>
              <h2>Nuevo workspace</h2>
            </div>
          </div>
          <WorkspaceForm
            organizations={organizations}
            onSubmit={handleCreate}
            onCancel={() => setShowCreate(false)}
            submitting={submitting}
          />
        </section>
      ) : null}

      {editing ? (
        <section className="card">
          <div className="cardHeader">
            <div>
              <p className="eyebrow">EDIT</p>
              <h2>{editing.name}</h2>
            </div>
          </div>
          <WorkspaceForm
            organizations={organizations}
            initialValue={editing}
            onSubmit={handleUpdate}
            onCancel={() => setEditing(null)}
            submitting={submitting}
          />
        </section>
      ) : null}

      <section className="statGrid">
        <article className="statCard">
          <span>Organizations</span>
          <strong>{organizations.length}</strong>
          <small>Disponibles para tu usuario</small>
        </article>
        <article className="statCard">
          <span>Workspaces</span>
          <strong>{workspaces.length}</strong>
          <small>En todas tus organizaciones</small>
        </article>
        <article className="statCard">
          <span>Workspace activo</span>
          <strong>{activeWorkspace?.name || "Sin seleccionar"}</strong>
          <small>{activeWorkspace?.organization_name || "Crea un workspace"}</small>
        </article>
        <article className="statCard">
          <span>Context</span>
          <strong>Active</strong>
          <small>The selected workspace scopes the product experience</small>
        </article>
      </section>

      <section className="card">
        <div className="cardHeader responsiveCardHeader">
          <div>
            <p className="eyebrow">AVAILABLE</p>
            <h2>Mis workspaces</h2>
          </div>
          <label className="compactField">
            Organización
            <select value={organizationFilter} onChange={(event) => setOrganizationFilter(event.target.value)}>
              <option value="ALL">Todas</option>
              {organizations.map((organization) => (
                <option value={organization.id} key={organization.id}>{organization.name}</option>
              ))}
            </select>
          </label>
        </div>

        {isLoading && workspaces.length === 0 ? (
          <p className="muted">Cargando workspaces...</p>
        ) : visibleWorkspaces.length === 0 ? (
          <EmptyState
            title="No hay workspaces"
            description="Crea un workspace para establecer el contexto operativo de la plataforma."
          />
        ) : (
          <div className="tableWrap">
            <table className="dataTable">
              <thead>
                <tr>
                  <th>Workspace</th>
                  <th>Organización</th>
                  <th>Estado</th>
                  <th>Descripción</th>
                  <th>Contexto</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {visibleWorkspaces.map((workspace) => {
                  const role = roleFor(workspace);
                  const canWrite = ["OWNER", "ADMIN", "BUILDER"].includes(role);
                  const isActive = workspace.id === activeWorkspace?.id;

                  return (
                    <tr key={workspace.id} className={isActive ? "activeTableRow" : ""}>
                      <td>
                        <strong>{workspace.name}</strong>
                        <small className="tableSecondary">{workspace.slug}</small>
                      </td>
                      <td>{workspace.organization_name}</td>
                      <td><span className={`statusBadge status-${workspace.status}`}>{workspace.status}</span></td>
                      <td>{workspace.description || <span className="muted">Sin descripción</span>}</td>
                      <td>
                        <button
                          type="button"
                          className={`button buttonSmall ${isActive ? "buttonPrimary" : "buttonGhost"}`}
                          onClick={() => setActiveWorkspace(workspace)}
                        >
                          {isActive ? "Activo" : "Seleccionar"}
                        </button>
                      </td>
                      <td>
                        <div className="tableActions">
                          <button
                            type="button"
                            className="button buttonGhost buttonSmall"
                            onClick={() => setEditing(workspace)}
                            disabled={!canWrite}
                            title={canWrite ? "Editar" : "No tienes permisos de escritura"}
                          >
                            Editar
                          </button>
                          <button
                            type="button"
                            className="button buttonDanger buttonSmall"
                            onClick={() => handleDelete(workspace)}
                            disabled={!canWrite}
                            title={canWrite ? "Eliminar" : "No tienes permisos de escritura"}
                          >
                            Eliminar
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
