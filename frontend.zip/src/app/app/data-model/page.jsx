"use client";

import { useEffect, useMemo, useState } from "react";

import DataHubTabs from "@/components/data/DataHubTabs";
import ManagedTableForm from "@/components/dataModel/ManagedTableForm";
import ModelInspector from "@/components/dataModel/ModelInspector";
import VisualDataModel from "@/components/dataModel/VisualDataModel";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import Spinner from "@/components/ui/Spinner";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { listDataSources } from "@/lib/services/dataSources";
import { createManagedTable, listCatalogRelations, listCatalogTables } from "@/lib/services/dataModel";
import { getApiErrorMessage } from "@/lib/utils/errors";

const WRITE_ROLES = ["OWNER", "ADMIN", "BUILDER"];

export default function DataModelPage() {
  const { activeWorkspace, organizations } = useWorkspace();
  const [sources, setSources] = useState([]);
  const [tables, setTables] = useState([]);
  const [relations, setRelations] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showBuilder, setShowBuilder] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const currentOrganization = useMemo(
    () => organizations.find((item) => item.id === activeWorkspace?.organization),
    [organizations, activeWorkspace],
  );
  const canWrite = WRITE_ROLES.includes(currentOrganization?.current_user_role);
  const managedSourceIds = useMemo(() => sources.filter((item) => item.mode === "MANAGED").map((item) => item.id), [sources]);
  const managedTables = useMemo(() => tables.filter((item) => managedSourceIds.includes(item.data_source)), [tables, managedSourceIds]);
  const selectedTable = useMemo(() => tables.find((item) => item.id === selectedId) || null, [tables, selectedId]);
  const selectedSource = useMemo(() => sources.find((item) => item.id === selectedTable?.data_source) || null, [sources, selectedTable]);

  async function loadModel() {
    if (!activeWorkspace?.id) { setSources([]); setTables([]); setRelations([]); setSelectedId(null); return; }
    setIsLoading(true); setError("");
    try {
      const sourceData = await listDataSources(activeWorkspace.id);
      setSources(sourceData);
      const [tableGroups, relationGroups] = await Promise.all([
        Promise.all(sourceData.map((source) => listCatalogTables(source.id))),
        Promise.all(sourceData.map((source) => listCatalogRelations(source.id))),
      ]);
      const nextTables = tableGroups.flat();
      setTables(nextTables);
      setRelations(relationGroups.flat());
      setSelectedId((current) => current && nextTables.some((table) => table.id === current) ? current : nextTables[0]?.id || null);
    } catch (requestError) { setError(getApiErrorMessage(requestError)); }
    finally { setIsLoading(false); }
  }

  useEffect(() => { loadModel(); }, [activeWorkspace?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  async function createTable(payload) {
    setIsSaving(true); setError(""); setMessage("");
    try {
      const table = await createManagedTable(payload);
      setMessage(`Tabla ${table.schema_name}.${table.table_name} creada correctamente.`);
      setShowBuilder(false);
      await loadModel();
      setSelectedId(table.id);
    } catch (requestError) { setError(getApiErrorMessage(requestError)); }
    finally { setIsSaving(false); }
  }

  if (!activeWorkspace) return <EmptyState title="Selecciona un workspace" description="Data Model requiere un workspace activo." />;

  return <div className="pageStack dataHubPage visualModelPage">
    <DataHubTabs />
    <header className="pageHeader pageHeaderActions">
      <div><p className="eyebrow">Data</p><h1>Model</h1><p>Visualiza tablas, campos y relaciones del workspace <strong>{activeWorkspace.name}</strong> en un único canvas.</p></div>
      {canWrite && <button type="button" className="button primaryButton" onClick={() => setShowBuilder((value) => !value)}>{showBuilder ? "Cerrar builder" : "Nueva tabla MANAGED"}</button>}
    </header>

    {error && <Alert type="error">{error}</Alert>}{message && <Alert type="success">{message}</Alert>}
    {!canWrite && <Alert type="info">Tu rol permite explorar el modelo, pero no crear tablas administradas.</Alert>}

    <section className="modelOverviewStrip">
      <div><span>Tables & views</span><strong>{tables.length}</strong></div>
      <div><span>Relationships</span><strong>{relations.length}</strong></div>
      <div><span>Managed</span><strong>{managedTables.length}</strong></div>
      <div><span>Sources</span><strong>{sources.length}</strong></div>
    </section>

    {showBuilder && <section className="card"><div className="cardHeader"><div><h2>Crear tabla administrada</h2><p>El backend creará schema, tabla física, DataAsset, TableAsset, campos y relaciones.</p></div></div><ManagedTableForm workspaceId={activeWorkspace.id} managedTables={managedTables} onSubmit={createTable} onCancel={() => setShowBuilder(false)} isSaving={isSaving} /></section>}

    {isLoading ? <section className="card"><Spinner label="Cargando modelo visual..." /></section> : tables.length === 0 ? <EmptyState title="No hay tablas catalogadas" description="Crea una tabla MANAGED o sincroniza el catálogo de una fuente externa para construir el modelo visual." /> : <section className="modelWorkspace">
      <VisualDataModel workspaceId={activeWorkspace.id} tables={tables} relations={relations} sources={sources} selectedId={selectedId} onSelect={setSelectedId} />
      <ModelInspector table={selectedTable} source={selectedSource} relations={relations} tables={tables} />
    </section>}
  </div>;
}
