"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

import DataHubTabs from "@/components/data/DataHubTabs";
import EmptyState from "@/components/ui/EmptyState";
import Icon from "@/components/ui/Icon";
import Spinner from "@/components/ui/Spinner";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { listDataAssets, listDataSources } from "@/lib/services/dataSources";
import { getApiErrorMessage } from "@/lib/utils/errors";

const FILTERS = ["ALL", "TABLE", "VIEW", "DERIVED_TABLE", "DATASET", "METRIC", "CHART", "DASHBOARD", "REPORT", "ML_MODEL", "OPTIMIZATION_MODEL", "OTHER"];

function assetIcon(type) {
  if (["TABLE", "VIEW", "DERIVED_TABLE", "DATASET"].includes(type)) return "table";
  if (type === "METRIC") return "measure";
  if (type === "CHART") return "chart";
  if (type === "DASHBOARD") return "dashboard";
  if (type === "REPORT") return "report";
  if (type === "ML_MODEL") return "brain";
  if (type === "OPTIMIZATION_MODEL") return "optimize";
  return "catalog";
}

export default function DataAssetsPage() {
  const { activeWorkspace } = useWorkspace();
  const [assets, setAssets] = useState([]);
  const [sources, setSources] = useState([]);
  const [filter, setFilter] = useState("ALL");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!activeWorkspace?.id) { setAssets([]); setSources([]); return; }
    setLoading(true); setError("");
    Promise.all([listDataAssets(activeWorkspace.id), listDataSources(activeWorkspace.id)])
      .then(([nextAssets, nextSources]) => { setAssets(nextAssets || []); setSources(nextSources || []); })
      .catch((requestError) => setError(getApiErrorMessage(requestError)))
      .finally(() => setLoading(false));
  }, [activeWorkspace?.id]);

  const visible = useMemo(() => assets.filter((asset) => {
    const matchesType = filter === "ALL" || asset.asset_type === filter;
    const haystack = `${asset.name} ${asset.asset_type} ${asset.data_source_name || ""} ${asset.physical_schema || ""} ${asset.physical_name || ""}`.toLowerCase();
    return matchesType && haystack.includes(query.trim().toLowerCase());
  }), [assets, filter, query]);

  if (!activeWorkspace) return <EmptyState title="Select a workspace" description="Catalog content is scoped to the active workspace." />;

  return <div className="pageStack dataHubPage">
    <header className="pageHeader pageHeaderActions"><div><p className="eyebrow">Data</p><h1>Catalog</h1><p>Search the workspace by business object instead of navigating technical modules.</p></div><Link className="button primaryButton" href="/app/data-sources">Connect data</Link></header>
    <DataHubTabs />
    {error ? <div className="alert alert-error">{error}</div> : null}
    <section className="catalogToolbar">
      <label className="catalogSearch"><Icon name="explore" size={17}/><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search tables, datasets, metrics, models..." /></label>
      <select aria-label="Filter by type" value={filter} onChange={(event) => setFilter(event.target.value)}>{FILTERS.map((item) => <option value={item} key={item}>{item === "ALL" ? "All types" : item.replaceAll("_", " ")}</option>)}</select>
    </section>
    {loading ? <Spinner label="Loading catalog..." /> : visible.length === 0 ? <EmptyState title={assets.length ? "No matching data" : "Catalog is empty"} description={assets.length ? "Try another search or object type." : "Connect a source and sync its catalog, create a managed table, or import a file before moving to analysis."} actionHref={!assets.length ? "/app/data-sources" : ""} actionLabel={!assets.length ? "Connect or sync data" : ""} secondaryHref={!assets.length ? "/app/get-started" : ""} secondaryLabel={!assets.length ? "Setup guide" : ""} /> : <section className="catalogGrid">
      {visible.map((asset) => { const source = sources.find((item) => item.id === asset.data_source); return <Link className="catalogCard" href={`/app/data-assets/${asset.id}`} key={asset.id}>
        <div className="catalogCardTop"><span className="catalogAssetIcon"><Icon name={assetIcon(asset.asset_type)} size={18}/></span><span className={`statusBadge status-${asset.status}`}>{asset.status}</span></div>
        <h2>{asset.name}</h2><p>{asset.asset_type.replaceAll("_", " ")}</p>
        <div className="catalogCardMeta"><span>{asset.data_source_name || "Platform generated"}</span><span>v{asset.version ?? 0}</span></div>
        <div className="catalogCardFoot"><span>{source?.mode || (asset.data_source ? "SOURCE" : "DERIVED")}</span><span>{asset.physical_schema && asset.physical_name ? `${asset.physical_schema}.${asset.physical_name}` : "Logical asset"}</span></div>
      </Link>; })}
    </section>}
  </div>;
}
