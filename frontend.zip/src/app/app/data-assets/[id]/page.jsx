"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

import DataHubTabs from "@/components/data/DataHubTabs";
import EmptyState from "@/components/ui/EmptyState";
import Icon from "@/components/ui/Icon";
import Spinner from "@/components/ui/Spinner";
import { getDataAsset, getDataSource } from "@/lib/services/dataSources";
import { getCatalogTable, listCatalogRelations, listCatalogTables } from "@/lib/services/dataModel";
import { getLineage } from "@/lib/services/dependencies";
import { listRecords } from "@/lib/services/records";
import { getApiErrorMessage } from "@/lib/utils/errors";

const TABS = ["Overview", "Data", "Schema", "Relationships", "Lineage"];

function cell(value) { if (value == null) return "NULL"; if (typeof value === "object") return JSON.stringify(value); return String(value); }

export default function CatalogAssetDetailPage() {
  const { id } = useParams();
  const [asset, setAsset] = useState(null);
  const [source, setSource] = useState(null);
  const [table, setTable] = useState(null);
  const [relations, setRelations] = useState([]);
  const [lineage, setLineage] = useState(null);
  const [rows, setRows] = useState([]);
  const [returned, setReturned] = useState(0);
  const [tab, setTab] = useState("Overview");
  const [loading, setLoading] = useState(true);
  const [dataLoading, setDataLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!id) return;
    let alive = true;
    (async () => {
      setLoading(true); setError("");
      try {
        const nextAsset = await getDataAsset(id);
        if (!alive) return;
        setAsset(nextAsset);
        const [nextSource, nextLineage] = await Promise.all([
          nextAsset.data_source ? getDataSource(nextAsset.data_source).catch(() => null) : Promise.resolve(null),
          getLineage(id).catch(() => null),
        ]);
        if (!alive) return;
        setSource(nextSource); setLineage(nextLineage);
        if (nextAsset.data_source) {
          const tables = await listCatalogTables(nextAsset.data_source);
          const match = (tables || []).find((item) => String(item.data_asset) === String(nextAsset.id));
          if (match && alive) {
            const fullTable = await getCatalogTable(match.id);
            setTable(fullTable);
            const nextRelations = await listCatalogRelations(nextAsset.data_source).catch(() => []);
            if (alive) setRelations((nextRelations || []).filter((relation) => relation.source_table === fullTable.id || relation.target_table === fullTable.id));
          }
        }
      } catch (requestError) { if (alive) setError(getApiErrorMessage(requestError)); }
      finally { if (alive) setLoading(false); }
    })();
    return () => { alive = false; };
  }, [id]);

  const isManagedTable = source?.mode === "MANAGED" && Boolean(table);
  const physicalName = asset?.physical_schema && asset?.physical_name ? `${asset.physical_schema}.${asset.physical_name}` : "Not materialized as a database table";

  async function loadData() {
    if (!isManagedTable || !table?.id) return;
    setDataLoading(true); setError("");
    try { const data = await listRecords(table.id, { limit: 25, offset: 0 }); setRows(data.rows || []); setReturned(data.returned || 0); }
    catch (requestError) { setError(getApiErrorMessage(requestError)); }
    finally { setDataLoading(false); }
  }

  useEffect(() => { if (tab === "Data" && isManagedTable && rows.length === 0) loadData(); }, [tab, isManagedTable]); // eslint-disable-line react-hooks/exhaustive-deps

  if (loading) return <Spinner label="Opening catalog object..." />;
  if (!asset) return <EmptyState title="Data object not available" description={error || "The catalog object could not be found."} />;

  return <div className="pageStack dataHubPage">
    <DataHubTabs />
    <header className="assetDetailHeader">
      <div className="assetDetailIdentity"><span className="catalogAssetIcon large"><Icon name={["TABLE","VIEW","DERIVED_TABLE","DATASET"].includes(asset.asset_type) ? "table" : "catalog"} size={21}/></span><div><div className="assetTitleLine"><h1>{asset.name}</h1><span className={`statusBadge status-${asset.status}`}>{asset.status}</span></div><p>{asset.asset_type.replaceAll("_", " ")} · {source?.name || "Platform generated"} · version {asset.version ?? 0}</p></div></div>
      <div className="formActions"><Link className="button secondaryButton" href="/app/data-assets">Back to catalog</Link>{isManagedTable ? <Link className="button primaryButton" href={`/app/records/${table.id}`}>Edit data</Link> : null}</div>
    </header>
    {error ? <div className="alert alert-error">{error}</div> : null}
    <nav className="assetTabs">{TABS.map((item) => <button type="button" className={tab === item ? "active" : ""} onClick={() => setTab(item)} key={item}>{item}</button>)}</nav>

    {tab === "Overview" ? <section className="assetOverviewGrid">
      <div className="dataHubPanel assetMainPanel"><div className="sectionHeading"><div><p className="eyebrow">About</p><h2>Data object</h2></div></div><dl className="assetDefinitionList">
        <div><dt>Source</dt><dd>{source?.name || "Generated by the platform"}</dd></div><div><dt>Mode</dt><dd>{source?.mode || "DERIVED"}</dd></div><div><dt>Physical object</dt><dd><code>{physicalName}</code></dd></div><div><dt>Fields</dt><dd>{table?.fields?.length ?? "—"}</dd></div><div><dt>Primary key</dt><dd>{table?.primary_key_columns?.join(", ") || "—"}</dd></div><div><dt>Updated</dt><dd>{asset.updated_at ? new Date(asset.updated_at).toLocaleString() : "—"}</dd></div>
      </dl></div>
      <div className="dataHubPanel"><div className="sectionHeading"><div><p className="eyebrow">Context</p><h2>How to use it</h2></div></div><div className="assetActionList">
        {isManagedTable ? <Link href={`/app/records/${table.id}`}><Icon name="table" size={17}/><span><strong>Work with rows</strong><small>Read and write managed records.</small></span></Link> : null}
        <Link href="/app/analytics"><Icon name="explore" size={17}/><span><strong>Analyze</strong><small>Use this data in an analysis workflow.</small></span></Link>
        <Link href="/app/transformations"><Icon name="transform" size={17}/><span><strong>Prepare data</strong><small>Create a derived transformation.</small></span></Link>
        {source ? <Link href={`/app/data-sources/${source.id}`}><Icon name="plug" size={17}/><span><strong>Open source</strong><small>Connection and catalog settings.</small></span></Link> : null}
      </div></div>
    </section> : null}

    {tab === "Data" ? <section className="dataHubPanel">
      <div className="sectionHeading"><div><p className="eyebrow">Preview</p><h2>Data</h2></div>{isManagedTable ? <div className="formActions"><button type="button" className="button secondaryButton smallButton" onClick={loadData}>Refresh</button><Link className="button primaryButton smallButton" href={`/app/records/${table.id}`}>Open editor</Link></div> : null}</div>
      {!table ? <EmptyState title="No tabular schema available" description="This asset is cataloged, but the backend does not expose it as a TableAsset." /> : !isManagedTable ? <EmptyState title="Preview is connection-specific" description={source?.mode === "EXTERNAL" ? "External data is intentionally read with runtime credentials from the source connection. Open the source to preview it without persisting secrets." : "This object is not available through the managed Records Engine."} /> : dataLoading ? <Spinner label="Loading rows..." /> : rows.length === 0 ? <EmptyState title="No rows" description="The managed table returned no records." /> : <><p className="mutedText">Showing {returned} row(s), first page.</p><div className="tableWrap"><table className="dataTable compactDataPreview"><thead><tr>{Object.keys(rows[0]).map((key) => <th key={key}>{key}</th>)}</tr></thead><tbody>{rows.map((row,index) => <tr key={index}>{Object.keys(rows[0]).map((key) => <td title={cell(row[key])} key={key}>{cell(row[key])}</td>)}</tr>)}</tbody></table></div></>}
    </section> : null}

    {tab === "Schema" ? <section className="dataHubPanel"><div className="sectionHeading"><div><p className="eyebrow">Structure</p><h2>Schema</h2></div></div>{!table ? <EmptyState title="Schema not available" description="There is no TableAsset attached to this catalog object." /> : <div className="tableWrap"><table className="dataTable"><thead><tr><th>Field</th><th>Business name</th><th>Type</th><th>Native</th><th>Nullable</th><th>Key</th></tr></thead><tbody>{(table.fields || []).map((field) => <tr key={field.id}><td><strong>{field.name}</strong><span className="tableSecondary">{field.description || ""}</span></td><td>{field.business_name || "—"}</td><td>{field.logical_type}</td><td><code>{field.native_type}</code></td><td>{field.nullable ? "Yes" : "No"}</td><td>{field.is_primary_key ? "PK" : field.is_identity ? "Identity" : "—"}</td></tr>)}</tbody></table></div>}</section> : null}

    {tab === "Relationships" ? <section className="dataHubPanel"><div className="sectionHeading"><div><p className="eyebrow">Model</p><h2>Relationships</h2></div><Link href="/app/data-model">Open model</Link></div>{!table ? <EmptyState title="Relationships unavailable" description="This asset has no TableAsset in the catalog." /> : relations.length === 0 ? <EmptyState title="No relationships" description="No foreign-key relationships are registered for this table." /> : <div className="relationshipList">{relations.map((relation) => { const outgoing = relation.source_table === table.id; return <div key={relation.id}><span className="relationDirection">{outgoing ? "OUT" : "IN"}</span><div><strong>{relation.name}</strong><p><code>{relation.source}</code> <span>→</span> <code>{relation.target}</code></p><small>{relation.source_columns.join(", ")} → {relation.target_columns.join(", ")}</small></div></div>; })}</div>}</section> : null}

    {tab === "Lineage" ? <section className="dataHubPanel"><div className="sectionHeading"><div><p className="eyebrow">Flow</p><h2>Lineage</h2></div><Link href="/app/dependencies">Open full lineage</Link></div>{!lineage ? <EmptyState title="Lineage unavailable" description="No lineage information was returned for this asset." /> : <div className="lineageContext">
      <div className="lineageColumn"><span>UPSTREAM</span>{lineage.upstream?.length ? lineage.upstream.map((item) => <Link href={`/app/data-assets/${item.id}`} key={item.id}><strong>{item.name}</strong><small>{item.dependency_type} · {item.refresh_policy}</small></Link>) : <p>No upstream dependencies</p>}</div>
      <div className="lineageFocus"><span>{asset.asset_type}</span><strong>{asset.name}</strong></div>
      <div className="lineageColumn"><span>DOWNSTREAM</span>{lineage.downstream?.length ? lineage.downstream.map((item) => <Link href={`/app/data-assets/${item.id}`} key={item.id}><strong>{item.name}</strong><small>{item.dependency_type} · {item.refresh_policy}</small></Link>) : <p>No downstream dependencies</p>}</div>
    </div>}</section> : null}
  </div>;
}
