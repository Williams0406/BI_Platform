"use client";
import Link from "next/link";
import { useEffect,useMemo,useState } from "react";
import ReportForm from "@/components/analytics/ReportForm";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import Spinner from "@/components/ui/Spinner";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { createReport,deleteReport,listDashboards,listReports,updateReport } from "@/lib/services/analytics";
import { getApiErrorMessage } from "@/lib/utils/errors";
const WRITE_ROLES=["OWNER","ADMIN","BUILDER"];
function listValue(d){return Array.isArray(d)?d:d?.results||[];}
export default function ReportsPage(){
 const {activeWorkspace,organizations}=useWorkspace();const [reports,setReports]=useState([]);const [dashboards,setDashboards]=useState([]);const [loading,setLoading]=useState(true);const [error,setError]=useState("");const [message,setMessage]=useState("");const [show,setShow]=useState(false);const [editing,setEditing]=useState(null);const [saving,setSaving]=useState(false);
 const org=useMemo(()=>organizations.find(o=>o.id===activeWorkspace?.organization),[organizations,activeWorkspace]);const canWrite=WRITE_ROLES.includes(org?.current_user_role);
 async function load(){if(!activeWorkspace?.id){setLoading(false);return;}setLoading(true);setError("");try{const [r,d]=await Promise.all([listReports(activeWorkspace.id),listDashboards(activeWorkspace.id)]);setReports(listValue(r));setDashboards(listValue(d));}catch(e){setError(getApiErrorMessage(e));}finally{setLoading(false);}}
 useEffect(()=>{load();},[activeWorkspace?.id]);
 async function save(payload){setSaving(true);setError("");try{if(editing){await updateReport(editing.id,payload);setMessage("Reporte actualizado.");}else{await createReport(payload);setMessage("Reporte creado.");}setShow(false);setEditing(null);await load();}catch(e){setError(getApiErrorMessage(e));}finally{setSaving(false);}}
 async function remove(item){if(!window.confirm(`¿Eliminar el reporte "${item.name}"?`))return;try{await deleteReport(item.id);setMessage("Reporte eliminado.");await load();}catch(e){setError(getApiErrorMessage(e));}}
 if(!activeWorkspace)return <EmptyState title="Selecciona un workspace" description="Los reportes pertenecen a un workspace."/>;
 return <div className="pageStack"><header className="pageHeader pageHeaderActions"><div><p className="eyebrow">Business Intelligence</p><h1>Reports</h1><p>Define entregables de negocio asociados a Dashboards y a un formato de exportación preferido.</p></div>{canWrite&&<button type="button" className="button primaryButton" onClick={()=>{setEditing(null);setShow(true);}}>Nuevo reporte</button>}</header>{error&&<Alert type="error">{error}</Alert>}{message&&<Alert type="success">{message}</Alert>}<Alert type="info">En el backend actual ReportDefinition almacena definición y formato preferido. La exportación física PDF/XLSX/CSV se integrará con Import/Export en la Fase 11; en esta fase el reporte puede previsualizar su Dashboard asociado.</Alert>
 {show&&<section className="card"><div className="cardHeader"><div><h2>{editing?"Editar reporte":"Nuevo reporte"}</h2></div></div><ReportForm workspaceId={activeWorkspace.id} dashboards={dashboards} initialValue={editing} onSubmit={save} onCancel={()=>{setShow(false);setEditing(null);}} isSaving={saving}/></section>}
 <section className="card"><div className="cardHeader"><div><h2>Report Definitions</h2><p>{reports.length} reporte(s)</p></div></div>{loading?<Spinner label="Cargando reportes..."/>:reports.length===0?<EmptyState title="Sin reportes" description="Crea una definición y opcionalmente asóciala a un Dashboard."/>:<div className="tableWrap"><table className="dataTable"><thead><tr><th>Nombre</th><th>Dashboard</th><th>Formato</th><th>Descripción</th><th>Acciones</th></tr></thead><tbody>{reports.map(r=><tr key={r.id}><td><strong>{r.name}</strong></td><td>{dashboards.find(d=>d.id===r.dashboard)?.name||"—"}</td><td><span className="statusBadge">{r.default_export_format}</span></td><td>{r.description||"—"}</td><td><div className="tableActions"><Link className="button primaryButton smallButton" href={`/app/reports/${r.id}`}>Previsualizar</Link>{canWrite&&<><button type="button" className="button secondaryButton smallButton" onClick={()=>{setEditing(r);setShow(true);}}>Editar</button><button type="button" className="button dangerButton smallButton" onClick={()=>remove(r)}>Eliminar</button></>}</div></td></tr>)}</tbody></table></div>}</section></div>;
}
