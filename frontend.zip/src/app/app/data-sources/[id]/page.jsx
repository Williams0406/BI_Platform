"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

import RuntimeCredentialsForm from "@/components/dataSources/RuntimeCredentialsForm";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import Spinner from "@/components/ui/Spinner";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { getDataSource, previewDataSourceCatalog, readDataSourcePage, testDataSourceConnection } from "@/lib/services/dataSources";
import { getApiErrorMessage } from "@/lib/utils/errors";

const WRITE_ROLES = ["OWNER", "ADMIN", "BUILDER"];

function sanitizeRuntime(input) {
  const output = {};
  Object.entries(input || {}).forEach(([key, value]) => {
    if (value === "" || value === null || value === undefined) return;
    if (["port", "connect_timeout"].includes(key)) output[key] = Number(value);
    else output[key] = value;
  });
  return output;
}

export default function DataSourceDetailPage() {
  const params = useParams(); const sourceId = params.id;
  const { organizations, workspaces } = useWorkspace();
  const [source, setSource] = useState(null); const [runtime, setRuntime] = useState({}); const [catalog, setCatalog] = useState(null); const [selectedTable, setSelectedTable] = useState(null); const [preview, setPreview] = useState(null);
  const [schemasText, setSchemasText] = useState(""); const [includeViews, setIncludeViews] = useState(true); const [limit, setLimit] = useState(25); const [offset, setOffset] = useState(0);
  const [isLoading, setIsLoading] = useState(true); const [busyAction, setBusyAction] = useState(""); const [error, setError] = useState(""); const [result, setResult] = useState(null);

  useEffect(() => { (async () => { setIsLoading(true); setError(""); try { setSource(await getDataSource(sourceId)); } catch (e) { setError(getApiErrorMessage(e)); } finally { setIsLoading(false); } })(); }, [sourceId]);
  const sourceWorkspace = useMemo(() => workspaces.find((item) => item.id === source?.workspace), [workspaces, source]);
  const organization = useMemo(() => organizations.find((item) => item.id === sourceWorkspace?.organization), [organizations, sourceWorkspace]);
  const canManage = WRITE_ROLES.includes(organization?.current_user_role);
  const connectorSupported = source && ["POSTGRESQL", "SQLSERVER"].includes(source.engine) && source.mode !== "PRIVATE_GATEWAY";

  async function runTest() { setBusyAction("test"); setError(""); setResult(null); try { setResult(await testDataSourceConnection(source.id, sanitizeRuntime(runtime))); } catch (e) { setError(getApiErrorMessage(e)); } finally { setBusyAction(""); } }
  async function loadCatalog() { setBusyAction("catalog"); setError(""); setCatalog(null); setPreview(null); try { const schemas = schemasText.split(",").map((v) => v.trim()).filter(Boolean); const data = await previewDataSourceCatalog(source.id, { ...sanitizeRuntime(runtime), ...(schemas.length ? { schemas } : {}), include_views: includeViews }); setCatalog(data); if (data.tables?.length) setSelectedTable(data.tables[0]); } catch (e) { setError(getApiErrorMessage(e)); } finally { setBusyAction(""); } }
  async function loadPreview(table = selectedTable, nextOffset = offset) { if (!table) return; setBusyAction("read"); setError(""); try { const data = await readDataSourcePage(source.id, { ...sanitizeRuntime(runtime), schema: table.schema, table: table.name, limit: Number(limit), offset: Number(nextOffset) }); setPreview(data); setOffset(Number(nextOffset)); } catch (e) { setError(getApiErrorMessage(e)); } finally { setBusyAction(""); } }

  if (isLoading) return <Spinner label="Cargando Data Source..." />;
  if (!source) return <EmptyState title="Data Source no disponible" description={error || "No se encontró la fuente solicitada."} />;

  return <div className="pageStack"><header className="pageHeader pageHeaderActions"><div><p className="eyebrow">Data Source</p><h1>{source.name}</h1><p>{source.mode} · {source.engine} · {source.status}</p></div><Link href="/app/data-sources" className="button secondaryButton">Volver</Link></header>
    {error && <Alert type="error">{error}</Alert>}{!connectorSupported && <Alert type="info">Esta fuente no usa el Connector Layer directo de PostgreSQL/SQL Server. {source.mode === "PRIVATE_GATEWAY" ? "Las fuentes PRIVATE_GATEWAY se administrarán con Customer Gateway en la Fase 11." : "Las fuentes MANAGED se operarán mediante Data Model Builder y Records."}</Alert>}
    <section className="card"><div className="cardHeader"><div><h2>Configuración</h2><p>Las credenciales siguientes solo viajan en la solicitud actual y no se guardan como connection_metadata.</p></div></div><div className="summaryGrid"><div><span>Workspace</span><strong>{source.workspace}</strong></div><div><span>Modo</span><strong>{source.mode}</strong></div><div><span>Motor</span><strong>{source.engine}</strong></div><div><span>Capacidades</span><strong>{[source.can_read && "READ", source.can_write && "WRITE", source.can_ddl && "DDL"].filter(Boolean).join(" / ") || "Ninguna"}</strong></div></div>{connectorSupported && canManage && <><RuntimeCredentialsForm source={source} value={runtime} onChange={setRuntime} /><div className="formActions"><button type="button" className="button primaryButton" disabled={busyAction === "test"} onClick={runTest}>{busyAction === "test" ? "Probando..." : "Probar conexión"}</button></div></>}{result && <pre className="codePanel">{JSON.stringify(result, null, 2)}</pre>}</section>

    {connectorSupported && <section className="card"><div className="cardHeader"><div><h2>Catálogo</h2><p>Introspección de schemas, tablas, vistas, columnas, PK y FK.</p></div></div><div className="formGrid twoColumns"><label className="field"><span>Schemas (separados por coma)</span><input value={schemasText} onChange={(e) => setSchemasText(e.target.value)} placeholder="public, sales" /></label><label className="checkboxField"><input type="checkbox" checked={includeViews} onChange={(e) => setIncludeViews(e.target.checked)} /> Incluir vistas</label></div><div className="formActions"><button type="button" className="button primaryButton" disabled={busyAction === "catalog"} onClick={loadCatalog}>{busyAction === "catalog" ? "Consultando..." : "Cargar catálogo"}</button></div>
      {catalog && <div className="catalogLayout"><div className="catalogList"><div className="catalogTitle">{catalog.count} objetos</div>{catalog.tables?.map((table) => <button type="button" key={`${table.schema}.${table.name}`} className={`catalogItem ${selectedTable?.schema === table.schema && selectedTable?.name === table.name ? "selectedCatalogItem" : ""}`} onClick={() => { setSelectedTable(table); setPreview(null); setOffset(0); }}><strong>{table.schema}.{table.name}</strong><span>{table.table_type} · {table.columns?.length || 0} columnas</span></button>)}</div><div className="catalogDetail">{selectedTable ? <><div className="cardHeader responsiveCardHeader"><div><h3>{selectedTable.schema}.{selectedTable.name}</h3><p>{selectedTable.table_type}</p></div>{source.can_read && <button type="button" className="button secondaryButton" onClick={() => loadPreview(selectedTable, 0)}>Leer datos</button>}</div><div className="tableWrap"><table className="dataTable"><thead><tr><th>Columna</th><th>Tipo</th><th>Nativo</th><th>Nullable</th><th>PK</th></tr></thead><tbody>{selectedTable.columns?.map((column) => <tr key={column.name}><td><strong>{column.name}</strong></td><td>{column.data_type}</td><td>{column.native_type}</td><td>{column.nullable ? "Sí" : "No"}</td><td>{selectedTable.primary_key?.includes(column.name) ? "Sí" : "—"}</td></tr>)}</tbody></table></div>{selectedTable.foreign_keys?.length > 0 && <div className="subsectionCard"><h4>Foreign Keys</h4>{selectedTable.foreign_keys.map((fk) => <div key={fk.name} className="relationLine"><code>{fk.source_columns.join(", ")}</code><span>→</span><code>{fk.target_schema}.{fk.target_table} ({fk.target_columns.join(", ")})</code></div>)}</div>}</> : <EmptyState title="Selecciona una tabla" description="Selecciona un objeto del catálogo para inspeccionar sus columnas." />}</div></div>}
    </section>}

    {preview && <section className="card"><div className="cardHeader responsiveCardHeader"><div><h2>Data preview</h2><p>{selectedTable?.schema}.{selectedTable?.name} · {preview.returned} fila(s)</p></div><div className="paginationControls"><label>Filas <select value={limit} onChange={(e) => setLimit(e.target.value)}><option>10</option><option>25</option><option>50</option><option>100</option></select></label><button type="button" className="button smallButton secondaryButton" disabled={offset <= 0 || busyAction === "read"} onClick={() => loadPreview(selectedTable, Math.max(0, offset - Number(limit)))}>Anterior</button><button type="button" className="button smallButton secondaryButton" disabled={preview.returned < Number(limit) || busyAction === "read"} onClick={() => loadPreview(selectedTable, offset + Number(limit))}>Siguiente</button></div></div><div className="tableWrap">{preview.rows?.length ? <table className="dataTable"><thead><tr>{Object.keys(preview.rows[0]).map((key) => <th key={key}>{key}</th>)}</tr></thead><tbody>{preview.rows.map((row, index) => <tr key={index}>{Object.keys(preview.rows[0]).map((key) => <td key={key}>{row[key] === null ? <span className="mutedText">NULL</span> : typeof row[key] === "object" ? JSON.stringify(row[key]) : String(row[key])}</td>)}</tr>)}</tbody></table> : <EmptyState title="Sin filas" description="La consulta no devolvió registros." />}</div></section>}
  </div>;
}
