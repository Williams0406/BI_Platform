"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

import DataHubTabs from "@/components/data/DataHubTabs";
import DataSourceForm from "@/components/dataSources/DataSourceForm";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import Spinner from "@/components/ui/Spinner";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { createDataSource, deleteDataSource, listDataSources, updateDataSource } from "@/lib/services/dataSources";
import { getApiErrorMessage } from "@/lib/utils/errors";

const WRITE_ROLES = ["OWNER", "ADMIN", "BUILDER"];

export default function DataSourcesPage() {
  const { activeWorkspace, organizations } = useWorkspace();
  const [sources, setSources] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const currentOrganization = useMemo(
    () => organizations.find((item) => item.id === activeWorkspace?.organization),
    [organizations, activeWorkspace],
  );
  const canWrite = WRITE_ROLES.includes(currentOrganization?.current_user_role);

  async function loadSources() {
    if (!activeWorkspace?.id) { setSources([]); return; }
    setIsLoading(true); setError("");
    try { setSources(await listDataSources(activeWorkspace.id)); }
    catch (requestError) { setError(getApiErrorMessage(requestError)); }
    finally { setIsLoading(false); }
  }

  useEffect(() => { loadSources(); }, [activeWorkspace?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  async function save(payload) {
    setIsSaving(true); setError(""); setMessage("");
    try {
      if (editing) await updateDataSource(editing.id, payload);
      else await createDataSource(payload);
      setMessage(editing ? "Data Source actualizado." : "Data Source creado.");
      setEditing(null); setShowForm(false); await loadSources();
    } catch (requestError) { setError(getApiErrorMessage(requestError)); }
    finally { setIsSaving(false); }
  }

  async function remove(source) {
    if (!window.confirm(`¿Eliminar el Data Source "${source.name}"?`)) return;
    setError(""); setMessage("");
    try { await deleteDataSource(source.id); setMessage("Data Source eliminado."); await loadSources(); }
    catch (requestError) { setError(getApiErrorMessage(requestError)); }
  }

  if (!activeWorkspace) return <EmptyState title="Selecciona un workspace" description="Data Sources requiere un workspace activo. Crea o selecciona uno desde la barra superior." />;

  return <div className="pageStack dataHubPage">
    <DataHubTabs />
    <header className="pageHeader pageHeaderActions"><div><p className="eyebrow">Data</p><h1>Sources</h1><p>Administra dónde viven los datos del workspace <strong>{activeWorkspace.name}</strong> y qué capacidades están habilitadas.</p></div>{canWrite && <button type="button" className="button primaryButton" onClick={() => { setEditing(null); setShowForm(true); }}>Connect data</button>}</header>

    {error && <Alert type="error">{error}</Alert>}{message && <Alert type="success">{message}</Alert>}
    {!canWrite && <Alert type="info">Tu rol permite consultar las fuentes, pero no crearlas ni modificarlas.</Alert>}

    {showForm && <section className="card"><div className="cardHeader"><div><h2>{editing ? "Editar Data Source" : "Connect data"}</h2><p>Las contraseñas no se guardan en connection_metadata.</p></div></div><DataSourceForm key={editing?.id || "new"} source={editing} workspaceId={activeWorkspace.id} onSubmit={save} onCancel={() => { setEditing(null); setShowForm(false); }} isSaving={isSaving} /></section>}

    <section className="card"><div className="cardHeader responsiveCardHeader"><div><h2>Fuentes registradas</h2><p>{sources.length} fuente(s) en el workspace activo.</p></div><Link className="button secondaryButton" href="/app/data-assets">Browse catalog</Link></div>
      {isLoading ? <Spinner label="Cargando fuentes..." /> : sources.length === 0 ? <EmptyState title="No data sources yet" description="Connect a managed, external or private source. This is the first required step before Catalog, Explore or ML can use workspace data." actionHref={canWrite ? "/app/get-started" : ""} actionLabel={canWrite ? "Open setup guide" : ""} /> : <div className="tableWrap"><table className="dataTable"><thead><tr><th>Fuente</th><th>Modo / Motor</th><th>Estado</th><th>Capacidades</th><th>Conexión</th><th>Acciones</th></tr></thead><tbody>{sources.map((source) => {
        const connectorReady = ["POSTGRESQL", "SQLSERVER"].includes(source.engine) && source.mode !== "PRIVATE_GATEWAY";
        return <tr key={source.id}><td><strong>{source.name}</strong><span className="tableSecondary">{source.id}</span></td><td>{source.mode}<span className="tableSecondary">{source.engine}</span></td><td><span className={`statusBadge status-${source.status}`}>{source.status}</span></td><td><div className="capabilityList"><span className={source.can_read ? "capabilityOn" : "capabilityOff"}>READ</span><span className={source.can_write ? "capabilityOn" : "capabilityOff"}>WRITE</span><span className={source.can_ddl ? "capabilityOn" : "capabilityOff"}>DDL</span></div></td><td>{connectorReady ? <span className="statusBadge status-ACTIVE">Connector</span> : <span className="statusBadge">No directo</span>}</td><td><div className="tableActions"><Link className="button smallButton secondaryButton" href={`/app/data-sources/${source.id}`}>Abrir</Link>{canWrite && <><button type="button" className="button smallButton secondaryButton" onClick={() => { setEditing(source); setShowForm(true); }}>Editar</button><button type="button" className="button smallButton dangerButton" onClick={() => remove(source)}>Eliminar</button></>}</div></td></tr>;
      })}</tbody></table></div>}
    </section>
  </div>;
}
