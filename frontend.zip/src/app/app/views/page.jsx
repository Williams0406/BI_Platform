"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

import ViewDefinitionForm, { VIEW_TYPES } from "@/components/views/ViewDefinitionForm";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import Spinner from "@/components/ui/Spinner";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { listCatalogTables } from "@/lib/services/dataModel";
import { listDataSources } from "@/lib/services/dataSources";
import { createView, deleteView, listViews, updateView } from "@/lib/services/views";
import { getApiErrorMessage } from "@/lib/utils/errors";

const WRITE_ROLES = ["OWNER", "ADMIN", "BUILDER"];

export default function OperationalViewsPage() {
  const { activeWorkspace, organizations } = useWorkspace();
  const [views, setViews] = useState([]);
  const [tables, setTables] = useState([]);
  const [viewType, setViewType] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const organization = useMemo(() => organizations.find((item) => item.id === activeWorkspace?.organization), [organizations, activeWorkspace]);
  const canWrite = WRITE_ROLES.includes(organization?.current_user_role);

  async function load() {
    if (!activeWorkspace?.id) { setViews([]); setTables([]); setIsLoading(false); return; }
    setIsLoading(true); setError("");
    try {
      const [viewData, sourceData] = await Promise.all([
        listViews({ workspace: activeWorkspace.id, viewType }),
        listDataSources(activeWorkspace.id),
      ]);
      setViews(Array.isArray(viewData) ? viewData : viewData.results || []);
      const managedSources = (sourceData || []).filter((source) => source.mode === "MANAGED");
      const tableGroups = await Promise.all(managedSources.map((source) => listCatalogTables(source.id)));
      setTables(tableGroups.flat().filter((table) => table.object_type === "TABLE"));
    } catch (requestError) { setError(getApiErrorMessage(requestError)); }
    finally { setIsLoading(false); }
  }

  useEffect(() => { load(); }, [activeWorkspace?.id, viewType]);

  async function save(payload) {
    setIsSaving(true); setError(""); setMessage("");
    try {
      if (editing) {
        await updateView(editing.id, payload);
        setMessage("Vista actualizada.");
      } else {
        await createView(payload);
        setMessage("Vista creada. Ahora configura sus bindings.");
      }
      setEditing(null); setShowForm(false); await load();
    } catch (requestError) { setError(getApiErrorMessage(requestError)); }
    finally { setIsSaving(false); }
  }

  async function remove(view) {
    if (!window.confirm(`¿Eliminar la vista \"${view.name}\"?`)) return;
    setError(""); setMessage("");
    try { await deleteView(view.id); setMessage("Vista eliminada."); await load(); }
    catch (requestError) { setError(getApiErrorMessage(requestError)); }
  }

  if (!activeWorkspace) return <EmptyState title="Selecciona un workspace" description="Las vistas operativas se crean dentro de un workspace." />;

  return <div className="pageStack">
    <header className="pageHeader pageHeaderActions"><div><p className="eyebrow">Views & Binding Engine</p><h1>Operational Views</h1><p>Construye interfaces operativas conectadas a tablas MANAGED y habilita writeback mediante bindings.</p></div><div className="formActions"><select value={viewType} onChange={(e) => setViewType(e.target.value)}><option value="">Todos los tipos</option>{VIEW_TYPES.map((type) => <option key={type}>{type}</option>)}</select>{canWrite && <button type="button" className="button primaryButton" onClick={() => { setEditing(null); setShowForm(true); }}>Nueva vista</button>}</div></header>
    {error && <Alert type="error">{error}</Alert>}{message && <Alert type="success">{message}</Alert>}
    {!canWrite && <Alert type="info">Tu rol permite consultar vistas, pero no crearlas, modificarlas ni hacer writeback.</Alert>}
    {showForm && <section className="card"><div className="cardHeader"><div><h2>{editing ? "Editar vista" : "Nueva vista"}</h2><p>Los bindings se configuran después desde el detalle.</p></div></div><ViewDefinitionForm workspaceId={activeWorkspace.id} tables={tables} initialValue={editing} onSubmit={save} onCancel={() => { setShowForm(false); setEditing(null); }} isSaving={isSaving} /></section>}
    <section className="card"><div className="cardHeader"><div><h2>Vistas del workspace</h2><p>{views.length} definición(es)</p></div></div>{isLoading ? <Spinner label="Cargando vistas..." /> : views.length === 0 ? <EmptyState title="Sin vistas" description="Crea una vista TABLE, SPREADSHEET, KANBAN, MATRIX, FORM o CALENDAR." /> : <div className="tableWrap"><table className="dataTable"><thead><tr><th>Nombre</th><th>Tipo</th><th>Estado</th><th>Bindings</th><th>Contrato</th><th>Acciones</th></tr></thead><tbody>{views.map((view) => <tr key={view.id}><td><strong>{view.name}</strong></td><td><span className="statusBadge">{view.view_type}</span></td><td>{view.status}</td><td>{view.bindings?.length || 0}</td><td>{["KANBAN","MATRIX","CALENDAR","FORM"].includes(view.view_type) ? "Validar en detalle" : "Flexible"}</td><td><div className="tableActions"><Link className="button secondaryButton smallButton" href={`/app/views/${view.id}`}>Abrir</Link>{canWrite && <><button type="button" className="button secondaryButton smallButton" onClick={() => { setEditing(view); setShowForm(true); }}>Editar</button><button type="button" className="button dangerButton smallButton" onClick={() => remove(view)}>Eliminar</button></>}</div></td></tr>)}</tbody></table></div>}</section>
  </div>;
}
