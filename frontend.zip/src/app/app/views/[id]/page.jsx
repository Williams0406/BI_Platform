"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

import ActionRuleForm from "@/components/views/ActionRuleForm";
import BindingForm from "@/components/views/BindingForm";
import OperationalViewRenderer from "@/components/views/OperationalViewRenderer";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import Spinner from "@/components/ui/Spinner";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { getCatalogTable } from "@/lib/services/dataModel";
import { createActionRule, createBinding, deleteBinding, getView, getViewSchema, validateView } from "@/lib/services/views";
import { getApiErrorMessage } from "@/lib/utils/errors";

const WRITE_ROLES = ["OWNER", "ADMIN", "BUILDER"];

export default function ViewDetailPage() {
  const params = useParams();
  const { activeWorkspace, organizations } = useWorkspace();
  const [view, setView] = useState(null);
  const [schema, setSchema] = useState(null);
  const [table, setTable] = useState(null);
  const [contract, setContract] = useState(null);
  const [showBinding, setShowBinding] = useState(false);
  const [showAction, setShowAction] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const organization = useMemo(() => organizations.find((item) => item.id === activeWorkspace?.organization), [organizations, activeWorkspace]);
  const canWrite = WRITE_ROLES.includes(organization?.current_user_role);

  async function load() {
    if (!params.id) return;
    setIsLoading(true); setError("");
    try {
      const definition = await getView(params.id);
      const [schemaData, contractData, tableData] = await Promise.all([
        getViewSchema(params.id), validateView(params.id), getCatalogTable(definition.source_table),
      ]);
      setView(definition); setSchema(schemaData); setContract(contractData); setTable(tableData);
    } catch (requestError) { setError(getApiErrorMessage(requestError)); }
    finally { setIsLoading(false); }
  }

  useEffect(() => { load(); }, [params.id]);

  async function addBinding(payload) {
    setIsSaving(true); setError(""); setMessage("");
    try { await createBinding(view.id, payload); setShowBinding(false); setMessage("Binding agregado."); await load(); }
    catch (requestError) { setError(getApiErrorMessage(requestError)); }
    finally { setIsSaving(false); }
  }

  async function removeBinding(binding) {
    if (!window.confirm(`¿Eliminar binding ${binding.role} → ${binding.field_name || binding.field}?`)) return;
    setError(""); setMessage("");
    try { await deleteBinding(view.id, binding.id); setMessage("Binding eliminado."); await load(); }
    catch (requestError) { setError(getApiErrorMessage(requestError)); }
  }

  async function addAction(payload) {
    setIsSaving(true); setError(""); setMessage("");
    try { await createActionRule(view.id, payload); setShowAction(false); setMessage("Regla de acción agregada."); await load(); }
    catch (requestError) { setError(getApiErrorMessage(requestError)); }
    finally { setIsSaving(false); }
  }

  if (isLoading && !view) return <Spinner label="Cargando View & Binding Engine..." />;
  if (!view || !schema || !table) return <EmptyState title="Vista no disponible" description={error || "No se pudo cargar la definición."} />;

  return <div className="pageStack">
    <header className="pageHeader pageHeaderActions"><div><p className="eyebrow">{view.view_type}</p><h1>{view.name}</h1><p>{schema.source_table.schema}.{schema.source_table.table} · {view.status}</p></div><div className="formActions"><Link className="button secondaryButton" href="/app/views">Volver</Link><button type="button" className="button secondaryButton" onClick={load}>Recargar</button></div></header>
    {error && <Alert type="error">{error}</Alert>}{message && <Alert type="success">{message}</Alert>}
    <section className="viewContractSummary"><div className="metricCard"><span>Contrato</span><strong>{contract?.valid ? "VALID" : "INVALID"}</strong></div><div className="metricCard"><span>Bindings</span><strong>{view.bindings?.length || 0}</strong></div><div className="metricCard"><span>Action Rules</span><strong>{view.action_rules?.length || 0}</strong></div><div className="metricCard"><span>PK</span><strong>{schema.source_table.primary_key?.join(", ") || "—"}</strong></div></section>
    {!contract?.valid && <Alert type="error">Contrato incompleto. Faltan roles: {(contract?.missing_roles || []).join(", ") || contract?.detail || "revisión requerida"}.</Alert>}
    <section className="card"><div className="cardHeader responsiveCardHeader"><div><h2>Bindings</h2><p>Define cómo cada FieldAsset participa en la vista y si puede escribir sobre la tabla.</p></div>{canWrite && <button type="button" className="button primaryButton smallButton" onClick={() => setShowBinding((value) => !value)}>Agregar binding</button>}</div>{showBinding && <BindingForm fields={table.fields || []} bindings={view.bindings || []} onSubmit={addBinding} onCancel={() => setShowBinding(false)} isSaving={isSaving} />}{(view.bindings || []).length === 0 ? <EmptyState title="Sin bindings" description="Agrega bindings para definir columnas, título, estado, filas, fechas o campos editables." /> : <div className="tableWrap"><table className="dataTable"><thead><tr><th>Pos.</th><th>Campo</th><th>Tipo</th><th>Rol</th><th>Alias</th><th>Editable</th><th>Required</th><th></th></tr></thead><tbody>{view.bindings.map((binding) => <tr key={binding.id}><td>{binding.position}</td><td>{binding.field_name}</td><td>{binding.logical_type}</td><td><span className="statusBadge">{binding.role}</span></td><td>{binding.alias || "—"}</td><td>{binding.editable ? "Sí" : "No"}</td><td>{binding.required ? "Sí" : "No"}</td><td>{canWrite && <button type="button" className="button dangerButton smallButton" onClick={() => removeBinding(binding)}>Eliminar</button>}</td></tr>)}</tbody></table></div>}</section>
    <section className="card"><div className="cardHeader responsiveCardHeader"><div><h2>Action Rules</h2><p>Metadatos de interacción. El backend aplica la autorización efectiva de writeback mediante bindings.</p></div>{canWrite && <button type="button" className="button secondaryButton smallButton" onClick={() => setShowAction((value) => !value)}>Agregar regla</button>}</div>{showAction && <ActionRuleForm onSubmit={addAction} onCancel={() => setShowAction(false)} isSaving={isSaving} />}{(view.action_rules || []).length === 0 ? <p className="helperText">No hay reglas declarativas. Las interacciones básicas siguen dependiendo de bindings y del tipo de vista.</p> : <div className="tableWrap"><table className="dataTable"><thead><tr><th>Nombre</th><th>Acción</th><th>Enabled</th><th>Config</th></tr></thead><tbody>{view.action_rules.map((rule) => <tr key={rule.id}><td>{rule.name}</td><td>{rule.action_type}</td><td>{rule.enabled ? "Sí" : "No"}</td><td><code>{JSON.stringify(rule.config)}</code></td></tr>)}</tbody></table></div>}</section>
    <section className="card runtimeCard"><div className="cardHeader"><div><h2>Runtime Preview</h2><p>Interacciones visuales → `/interact/` → Records Engine → optimistic locking.</p></div></div><OperationalViewRenderer view={view} schema={{ ...schema, contract }} canWrite={canWrite} /></section>
  </div>;
}
