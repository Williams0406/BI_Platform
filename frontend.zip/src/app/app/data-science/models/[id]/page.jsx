"use client";

import Link from "next/link";
import { use, useEffect, useMemo, useState } from "react";

import ModelMetrics from "@/components/dataScience/ModelMetrics";
import ExecutionStatus from "@/components/logic/ExecutionStatus";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import Spinner from "@/components/ui/Spinner";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { listCatalogTables } from "@/lib/services/dataModel";
import {
  getModel,
  inferModelVersion,
  listDatasets,
  listModelRuns,
  listModelVersions,
  listPredictions,
  trainModel,
} from "@/lib/services/dataScience";
import { getExecution } from "@/lib/services/executions";
import { getApiErrorMessage } from "@/lib/utils/errors";

const WRITE_ROLES=["OWNER","ADMIN","BUILDER"];
function listValue(data){return Array.isArray(data)?data:data?.results||[];}
const TERMINAL=new Set(["SUCCESS","FAILED","CANCELLED","BLOCKED"]);
function date(value){return value?new Date(value).toLocaleString():"—";}

export default function ModelDetailPage({params}){
  const {id}=use(params);
  const {activeWorkspace,organizations}=useWorkspace();
  const [model,setModel]=useState(null);const [datasets,setDatasets]=useState([]);const [tables,setTables]=useState([]);const [runs,setRuns]=useState([]);const [versions,setVersions]=useState([]);const [predictions,setPredictions]=useState([]);const [execution,setExecution]=useState(null);const [inferDataset,setInferDataset]=useState("");const [loading,setLoading]=useState(true);const [busy,setBusy]=useState(false);const [error,setError]=useState("");const [message,setMessage]=useState("");
  const organization=useMemo(()=>organizations.find(x=>x.id===activeWorkspace?.organization),[organizations,activeWorkspace]);
  const canWrite=WRITE_ROLES.includes(organization?.current_user_role);
  const tableById=useMemo(()=>Object.fromEntries(tables.map(t=>[t.id,t])),[tables]);
  const datasetById=useMemo(()=>Object.fromEntries(datasets.map(d=>[d.id,d])),[datasets]);
  const modelVersionIds=useMemo(()=>new Set(versions.map(v=>v.id)),[versions]);

  async function load(){setLoading(true);setError("");try{
    const [modelData,datasetData,tableData,runData,versionData,predictionData]=await Promise.all([getModel(id),listDatasets(activeWorkspace?.id),listCatalogTables(),listModelRuns(id),listModelVersions(id),listPredictions()]);
    const ds=listValue(datasetData);const vs=listValue(versionData);
    setModel(modelData);setDatasets(ds);setTables(listValue(tableData));setRuns(listValue(runData));setVersions(vs);setPredictions(listValue(predictionData).filter(p=>vs.some(v=>v.id===p.model_version)));
    if(!inferDataset&&ds.length)setInferDataset(ds[0].id);
  }catch(e){setError(getApiErrorMessage(e));}finally{setLoading(false);}}
  useEffect(()=>{if(activeWorkspace?.id)load();},[id,activeWorkspace?.id]);

  useEffect(()=>{
    if(!execution?.id||TERMINAL.has(execution.status))return;
    const timer=setInterval(async()=>{try{const updated=await getExecution(execution.id);setExecution(updated);if(TERMINAL.has(updated.status)){await load();setMessage(updated.status==="SUCCESS"?"Proceso ML completado.":`Proceso finalizado: ${updated.status}`);}}catch{}},2000);
    return()=>clearInterval(timer);
  },[execution?.id,execution?.status]);

  async function train(){setBusy(true);setError("");setMessage("");try{const result=await trainModel(id);setExecution({id:result.execution_id,status:result.status,progress:0});setMessage(`Training run ${result.model_run_id} enviado a cola ml.`);}catch(e){setError(getApiErrorMessage(e));}finally{setBusy(false);}}
  async function infer(version){if(!inferDataset)return;setBusy(true);setError("");setMessage("");try{const result=await inferModelVersion(version.id,inferDataset);setExecution({id:result.execution_id,status:result.status,progress:0});setMessage(`Inferencia con versión v${version.version} enviada a cola ml.`);}catch(e){setError(getApiErrorMessage(e));}finally{setBusy(false);}}

  if(loading)return <Spinner label="Cargando modelo ML..."/>;
  if(!model)return <EmptyState title="Modelo no disponible" description={error||"No se pudo cargar el modelo."}/>;
  const dataset=datasetById[model.dataset];const table=tableById[dataset?.source_table];
  const fields=table?.fields||[];const fieldById=Object.fromEntries(fields.map(f=>[f.id,f]));

  return <div className="pageStack">
    <header className="pageHeader pageHeaderActions"><div><p className="eyebrow">Machine Learning · Model</p><h1>{model.name}</h1><p>{model.description||"Modelo versionado de clasificación o regresión."}</p></div><div className="headerActions"><Link className="button secondaryButton" href="/app/data-science">Back to ML</Link>{canWrite&&<button type="button" className="button primaryButton" onClick={train} disabled={busy||!model.enabled}>{busy?"Procesando...":"Train new version"}</button>}</div></header>
    {error&&<Alert type="error">{error}</Alert>}{message&&<Alert type="success">{message}</Alert>}

    <section className="mlLifecycle"><div className="done"><span>1</span><strong>Question defined</strong></div><i>→</i><div className="done"><span>2</span><strong>Data configured</strong></div><i>→</i><div className={versions.length?"done":"active"}><span>3</span><strong>Train & evaluate</strong></div><i>→</i><div className={predictions.length?"done":versions.length?"active":""}><span>4</span><strong>Use model</strong></div></section><section className="card"><div className="detailGrid"><div><span>Task</span><strong>{model.task_type}</strong></div><div><span>Algorithm</span><strong>{model.algorithm}</strong></div><div><span>Dataset</span><strong>{dataset?.name||model.dataset}</strong></div><div><span>Source table</span><strong>{table?`${table.schema_name}.${table.table_name}`:"—"}</strong></div><div><span>Target</span><strong>{fieldById[model.target]?.name||model.target}</strong></div><div><span>Features</span><strong>{model.features?.length||0}</strong></div><div><span>Test size</span><strong>{model.test_size}</strong></div><div><span>Random state</span><strong>{model.random_state}</strong></div></div><div className="chipList">{(model.features||[]).map(fid=><span className="dataChip" key={fid}><strong>{fieldById[fid]?.name||fid}</strong><small>{fieldById[fid]?.logical_type||"feature"}</small></span>)}</div>{model.parameters&&<pre className="codeBlock compactCode">{JSON.stringify(model.parameters,null,2)}</pre>}</section>

    {execution&&<section className="card"><div className="cardHeader"><div><h2>Proceso activo/reciente</h2><p>Training e inference comparten el Execution Engine.</p></div><Link href={`/app/executions/${execution.id}`} className="button secondaryButton">Abrir Execution</Link></div><div className="detailGrid"><div><span>Status</span><ExecutionStatus status={execution.status}/></div><div><span>Progress</span><strong>{execution.progress??0}%</strong></div><div><span>Execution ID</span><code>{execution.id}</code></div></div><div className="progressTrack"><div className="progressFill" style={{width:`${Math.max(0,Math.min(100,Number(execution.progress)||0))}%`}}/></div>{execution.result&&<pre className="codeBlock">{JSON.stringify(execution.result,null,2)}</pre>}</section>}

    <section className="card"><div className="cardHeader"><div><h2>Evaluation history</h2><p>Every training run keeps its holdout metrics and row counts.</p></div></div>{runs.length?<div className="dataTableWrap"><table className="dataTable"><thead><tr><th>Fecha</th><th>Status</th><th>Filas</th><th>Train/Test</th><th>Métricas</th><th>Execution</th></tr></thead><tbody>{runs.map(run=><tr key={run.id}><td>{date(run.created_at)}</td><td><ExecutionStatus status={run.status}/>{run.error_message&&<small className="tableSubtext errorText">{run.error_message}</small>}</td><td>{run.row_count}</td><td>{run.train_row_count} / {run.test_row_count}</td><td><ModelMetrics metrics={run.metrics}/></td><td>{run.execution_id?<Link href={`/app/executions/${run.execution_id}`}>Abrir</Link>:"—"}</td></tr>)}</tbody></table></div>:<EmptyState title="Sin training runs" description="Entrena el modelo para generar su primera versión."/>}</section>

    <section className="card"><div className="cardHeader"><div><h2>Ready-to-use versions</h2><p>Every successful training creates an immutable version with reproducible metrics.</p></div></div>{versions.length?<div className="versionList">{versions.map(version=><article className="versionCard" key={version.id}><header><div><span className="versionBadge">v{version.version}</span><strong>{version.algorithm}</strong><small>sklearn {version.sklearn_version||"—"} · {date(version.created_at)}</small></div></header><ModelMetrics metrics={version.metrics}/><div className="detailGrid compactGrid"><div><span>Target</span><strong>{version.target_name}</strong></div><div><span>Features</span><strong>{version.feature_names?.join(", ")||"—"}</strong></div></div>{canWrite&&<div className="inferenceBar"><label className="fieldGroup growField"><span>Dataset para inferencia</span><select value={inferDataset} onChange={e=>setInferDataset(e.target.value)}>{datasets.map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</select></label><button type="button" className="button primaryButton" onClick={()=>infer(version)} disabled={busy||!inferDataset}>Run predictions with v{version.version}</button></div>}<small className="artifactPath">Artifact: {version.artifact_path}</small></article>)}</div>:<EmptyState title="Sin versiones" description="Las versiones se crean automáticamente después de un entrenamiento exitoso."/>}</section>

    <section className="card"><div className="cardHeader"><div><h2>Prediction outputs</h2><p>Batch predictions become governed DATASET assets that can re-enter Catalog, Prepare and Analyze.</p></div></div>{predictions.length?<div className="dataTableWrap"><table className="dataTable"><thead><tr><th>Creado</th><th>Versión</th><th>Dataset</th><th>Filas</th><th>Data Asset</th><th>Artifact</th></tr></thead><tbody>{predictions.map(p=>{const version=versions.find(v=>v.id===p.model_version);return <tr key={p.id}><td>{date(p.created_at)}</td><td>v{version?.version||"?"}</td><td>{datasetById[p.source_dataset]?.name||p.source_dataset}</td><td>{p.row_count}</td><td><code>{p.data_asset}</code></td><td><span className="artifactPath">{p.artifact_path}</span></td></tr>;})}</tbody></table></div>:<EmptyState title="Sin predicciones" description="Ejecuta inferencia sobre una ModelVersion para generar un PredictionAsset y DataAsset DATASET."/>}</section>
  </div>;
}
