"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import DatasetForm from "@/components/dataScience/DatasetForm";
import MLWizard from "@/components/dataScience/MLWizard";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import Spinner from "@/components/ui/Spinner";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import { listCatalogTables } from "@/lib/services/dataModel";
import { listDataSources } from "@/lib/services/dataSources";
import { createDataset,createModel,deleteDataset,deleteModel,listDatasets,listModels,listModelRuns,listModelVersions,updateDataset } from "@/lib/services/dataScience";
import { getApiErrorMessage } from "@/lib/utils/errors";

const WRITE_ROLES=["OWNER","ADMIN","BUILDER"];
const listValue=data=>Array.isArray(data)?data:data?.results||[];
const date=v=>v?new Date(v).toLocaleDateString():"—";

export default function DataSciencePage(){
  const {activeWorkspace,organizations}=useWorkspace();
  const [datasets,setDatasets]=useState([]),[models,setModels]=useState([]),[tables,setTables]=useState([]),[runs,setRuns]=useState([]),[versions,setVersions]=useState([]);
  const [loading,setLoading]=useState(true),[error,setError]=useState(""),[message,setMessage]=useState(""),[mode,setMode]=useState("HOME"),[editingDataset,setEditingDataset]=useState(null),[saving,setSaving]=useState(false);
  const organization=useMemo(()=>organizations.find(x=>x.id===activeWorkspace?.organization),[organizations,activeWorkspace]);
  const canWrite=WRITE_ROLES.includes(organization?.current_user_role);
  const tableById=useMemo(()=>Object.fromEntries(tables.map(t=>[t.id,t])),[tables]);
  const latestRunByModel=useMemo(()=>{const m={};runs.forEach(r=>{if(!m[r.model]||new Date(r.created_at)>new Date(m[r.model].created_at))m[r.model]=r;});return m;},[runs]);
  const versionsByModel=useMemo(()=>versions.reduce((m,v)=>{m[v.model]=(m[v.model]||0)+1;return m;},{}),[versions]);

  async function load(){
    if(!activeWorkspace?.id){setLoading(false);return;}
    setLoading(true);setError("");
    try{
      const [ds,ms,src,tbl,rs,vs]=await Promise.all([listDatasets(activeWorkspace.id),listModels(activeWorkspace.id),listDataSources(activeWorkspace.id),listCatalogTables(),listModelRuns(),listModelVersions()]);
      const managedIds=new Set(listValue(src).filter(s=>s.mode==="MANAGED").map(s=>s.id));
      setDatasets(listValue(ds));setModels(listValue(ms));setTables(listValue(tbl).filter(t=>managedIds.has(t.data_source)&&t.object_type==="TABLE"));setRuns(listValue(rs));setVersions(listValue(vs));
    }catch(e){setError(getApiErrorMessage(e));}finally{setLoading(false);}
  }
  useEffect(()=>{load();},[activeWorkspace?.id]);

  async function createGuided({dataset,model}){
    setSaving(true);setError("");
    let createdDataset=null;
    try{
      createdDataset=await createDataset(dataset);
      const createdModel=await createModel({...model,dataset:createdDataset.id});
      setMessage("Model created. Review it and start training when ready.");setMode("HOME");await load();
      window.location.href=`/app/data-science/models/${createdModel.id}`;
    }catch(e){
      if(createdDataset?.id){try{await deleteDataset(createdDataset.id);}catch{}}
      setError(getApiErrorMessage(e));
    }finally{setSaving(false);}
  }
  async function saveDataset(payload){setSaving(true);try{if(editingDataset)await updateDataset(editingDataset.id,payload);else await createDataset(payload);setMessage("Dataset saved.");setMode("ADVANCED");setEditingDataset(null);await load();}catch(e){setError(getApiErrorMessage(e));}finally{setSaving(false);}}
  async function removeModel(m){if(!window.confirm(`Delete "${m.name}"?`))return;try{await deleteModel(m.id);await load();}catch(e){setError(getApiErrorMessage(e));}}
  async function removeDataset(d){if(!window.confirm(`Delete dataset "${d.name}"?`))return;try{await deleteDataset(d.id);await load();}catch(e){setError(getApiErrorMessage(e));}}

  if(!activeWorkspace)return <EmptyState title="Select a workspace" description="Machine Learning is scoped to the active workspace."/>;
  if(loading)return <Spinner label="Loading Machine Learning..."/>;

  return <div className="pageStack">
    <header className="pageHeader pageHeaderActions"><div><p className="eyebrow">AI & Optimization</p><h1>Machine Learning</h1><p>Build, train, evaluate and use predictive models without starting from backend objects.</p></div><div className="headerActions"><button type="button" className="button secondaryButton" onClick={()=>setMode(mode==="ADVANCED"?"HOME":"ADVANCED")}>{mode==="ADVANCED"?"Guided view":"Advanced"}</button>{canWrite&&<button type="button" className="button primaryButton" onClick={()=>setMode("WIZARD")}>+ New model</button>}</div></header>
    {error&&<Alert type="error">{error}</Alert>}{message&&<Alert type="success">{message}</Alert>}

    {mode==="WIZARD"&&<section className="card mlWizardCard"><MLWizard workspaceId={activeWorkspace.id} tables={tables} onCreate={createGuided} isSaving={saving} onCancel={()=>setMode("HOME")}/></section>}

    {mode==="HOME"&&<>
      <section className="mlHero">
        <div><span className="prepareFlowStep">1</span><strong>Define the question</strong><small>Category or numeric outcome</small></div><span>→</span>
        <div><span className="prepareFlowStep">2</span><strong>Choose training data</strong><small>Governed MANAGED table</small></div><span>→</span>
        <div><span className="prepareFlowStep">3</span><strong>Train & evaluate</strong><small>Versioned metrics and artifacts</small></div><span>→</span>
        <div><span className="prepareFlowStep">4</span><strong>Use the model</strong><small>Batch predictions become Data Assets</small></div>
      </section>
      <section className="statGrid">
        <div className="statCard"><span>Models</span><strong>{models.length}</strong><small>Definitions</small></div>
        <div className="statCard"><span>Trained versions</span><strong>{versions.length}</strong><small>Immutable artifacts</small></div>
        <div className="statCard"><span>Training datasets</span><strong>{datasets.length}</strong><small>Managed data</small></div>
        <div className="statCard"><span>Recent runs</span><strong>{runs.length}</strong><small>Training history</small></div>
      </section>
      <section className="card">
        <div className="cardHeader"><div><h2>Models</h2><p>Your predictive questions, their latest training state and reusable versions.</p></div>{canWrite&&models.length===0&&<button type="button" className="button primaryButton" onClick={()=>setMode("WIZARD")}>Create first model</button>}</div>
        {models.length?<div className="mlModelGrid">{models.map(m=>{const d=datasets.find(x=>x.id===m.dataset),t=tableById[d?.source_table],run=latestRunByModel[m.id];return <article className="mlModelCard" key={m.id}>
          <div className="mlModelCardHeader"><span className="prepareKind">{m.task_type==="CLASSIFICATION"?"CATEGORY":"NUMBER"}</span><span className={`statusBadge ${m.enabled?"status-success":"status-blocked"}`}>{m.enabled?"ACTIVE":"DISABLED"}</span></div>
          <div><h3>{m.name}</h3><p>{m.description||"No description"}</p></div>
          <div className="mlModelQuestion"><small>PREDICT</small><strong>{t?.fields?.find(f=>f.id===m.target)?.business_name||t?.fields?.find(f=>f.id===m.target)?.name||"Target"}</strong><span>from {m.features?.length||0} feature(s)</span></div>
          <div className="mlModelMeta"><span>{m.algorithm.replaceAll("_"," ")}</span><span>{versionsByModel[m.id]||0} version(s)</span><span>{run?`Last run ${run.status}`:"Not trained"}</span></div>
          <div className="tableActions"><Link className="button primaryButton smallButton" href={`/app/data-science/models/${m.id}`}>{run?"Open model":"Train model"}</Link>{canWrite&&<button type="button" className="button dangerButton smallButton" onClick={()=>removeModel(m)}>Delete</button>}</div>
        </article>})}</div>:<EmptyState title="No ML models yet" description={tables.length?"Start with a business question. The guided flow will create the technical dataset and model definition for you.":"Create or import a MANAGED table before building an ML model."}/>}
      </section>
    </>}

    {mode==="ADVANCED"&&<>
      <Alert type="info">Advanced mode exposes DatasetDefinition directly. `filter_config` is stored by the backend but is not currently applied by `dataset_to_dataframe`; use `sample_limit` for the supported runtime constraint.</Alert>
      {(editingDataset||canWrite)&&<section className="card"><div className="cardHeader"><div><h2>{editingDataset?"Edit training dataset":"Dataset definitions"}</h2><p>Use this only when you need explicit control over the reusable ML dataset object.</p></div>{!editingDataset&&<button type="button" className="button secondaryButton" onClick={()=>setEditingDataset({})}>+ Dataset</button>}</div>{editingDataset&&<DatasetForm workspaceId={activeWorkspace.id} tables={tables} initialValue={editingDataset.id?editingDataset:null} onSubmit={saveDataset} onCancel={()=>setEditingDataset(null)} isSaving={saving}/>}</section>}
      <section className="card"><div className="cardHeader"><div><h2>Datasets</h2><p>{datasets.length} definitions.</p></div></div>{datasets.length?<div className="dataTableWrap"><table className="dataTable"><thead><tr><th>Name</th><th>Source</th><th>Sample limit</th><th>Models</th><th>Actions</th></tr></thead><tbody>{datasets.map(d=>{const t=tableById[d.source_table];return <tr key={d.id}><td><strong>{d.name}</strong><small className="tableSubtext">{d.description||"No description"}</small></td><td>{t?`${t.schema_name}.${t.table_name}`:d.source_table}</td><td>{d.sample_limit??"All rows"}</td><td>{models.filter(m=>m.dataset===d.id).length}</td><td>{canWrite&&<div className="tableActions"><button type="button" className="button smallButton secondaryButton" onClick={()=>setEditingDataset(d)}>Edit</button><button type="button" className="button smallButton dangerButton" onClick={()=>removeDataset(d)}>Delete</button></div>}</td></tr>})}</tbody></table></div>:<EmptyState title="No datasets" description="The guided model builder creates a dataset automatically."/ >}</section>
    </>}
  </div>;
}
