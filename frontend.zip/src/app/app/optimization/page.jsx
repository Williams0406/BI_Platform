"use client";
import Link from "next/link";
import {useEffect,useMemo,useState} from "react";
import OptimizationModelForm from "@/components/optimization/OptimizationModelForm";
import OptimizationWizard from "@/components/optimization/OptimizationWizard";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import Spinner from "@/components/ui/Spinner";
import {useWorkspace} from "@/lib/hooks/useWorkspace";
import {createOptimizationModel,deleteOptimizationModel,listOptimizationModels,listOptimizationRuns,optimizationConstraints,optimizationObjectives,optimizationScenarios,optimizationVariables,solverConfigs,updateOptimizationModel} from "@/lib/services/optimization";
import {getApiErrorMessage} from "@/lib/utils/errors";
const WRITE_ROLES=["OWNER","ADMIN","BUILDER"]; const listValue=d=>Array.isArray(d)?d:d?.results||[];
export default function OptimizationPage(){
 const {activeWorkspace,organizations}=useWorkspace();
 const [items,setItems]=useState([]),[runs,setRuns]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(""),[message,setMessage]=useState(""),[editing,setEditing]=useState(undefined),[mode,setMode]=useState("HOME"),[saving,setSaving]=useState(false);
 const org=useMemo(()=>organizations.find(x=>x.id===activeWorkspace?.organization),[organizations,activeWorkspace]);const canWrite=WRITE_ROLES.includes(org?.current_user_role);
 async function load(){if(!activeWorkspace?.id){setItems([]);setLoading(false);return;}setLoading(true);setError("");try{const [m,r]=await Promise.all([listOptimizationModels(activeWorkspace.id),listOptimizationRuns()]);setItems(listValue(m));setRuns(listValue(r));}catch(e){setError(getApiErrorMessage(e));}finally{setLoading(false);}}
 useEffect(()=>{load();},[activeWorkspace?.id]);
 async function saveAdvanced(payload){setSaving(true);setError("");try{if(editing){await updateOptimizationModel(editing.id,payload);setMessage("Optimization model updated.");}else{const m=await createOptimizationModel(payload);setMessage("Optimization model created. Add variables, objective, scenario and solver in Advanced mode.");window.location.href=`/app/optimization/${m.id}`;}setMode("HOME");setEditing(undefined);await load();}catch(e){setError(getApiErrorMessage(e));}finally{setSaving(false);}}
 async function createGuided(bundle){setSaving(true);setError("");let model=null;try{
   model=await createOptimizationModel(bundle.model);const modelId=model.id;
   for(const v of bundle.variables)await optimizationVariables.create({model:modelId,...v});
   await optimizationObjectives.create({model:modelId,...bundle.objective});
   for(const c of bundle.constraints)await optimizationConstraints.create({model:modelId,...c});
   await solverConfigs.create({model:modelId,...bundle.solver});
   await optimizationScenarios.create({model:modelId,...bundle.scenario});
   setMessage("Decision model created. Review readiness and solve when ready.");window.location.href=`/app/optimization/${modelId}`;
 }catch(e){if(model?.id){try{await deleteOptimizationModel(model.id);}catch{}}setError(getApiErrorMessage(e));}finally{setSaving(false);}}
 async function remove(x){if(!confirm(`Delete decision model "${x.name}"?`))return;try{await deleteOptimizationModel(x.id);setMessage("Decision model deleted.");await load();}catch(e){setError(getApiErrorMessage(e));}}
 const runFor=id=>runs.filter(r=>r.model===id).sort((a,b)=>new Date(b.created_at)-new Date(a.created_at))[0];
 if(!activeWorkspace)return <EmptyState title="Select a workspace" description="Optimization belongs to the active workspace."/>;if(loading)return <Spinner label="Loading Optimization..."/>;
 return <div className="pageStack">
  <header className="pageHeader pageHeaderActions"><div><p className="eyebrow">AI & Optimization</p><h1>Optimization</h1><p>Turn a business decision into variables, an objective and rules; compare the optimized solution with the way you operate today.</p></div><div className="headerActions"><button type="button" className="button secondaryButton" onClick={()=>setMode(mode==="ADVANCED"?"HOME":"ADVANCED")}>{mode==="ADVANCED"?"Guided view":"Advanced"}</button>{canWrite&&<button type="button" className="button primaryButton" onClick={()=>setMode("WIZARD")}>+ New decision model</button>}</div></header>
  {error&&<Alert type="error">{error}</Alert>}{message&&<Alert type="success">{message}</Alert>}
  {mode==="WIZARD"&&<section className="card mlWizardCard"><OptimizationWizard workspaceId={activeWorkspace.id} onCreate={createGuided} onCancel={()=>setMode("HOME")} isSaving={saving}/></section>}
  {mode==="HOME"&&<>
   <section className="optHero"><div><span className="prepareFlowStep">1</span><strong>Decision</strong><small>What can change?</small></div><span>→</span><div><span className="prepareFlowStep">2</span><strong>Objective</strong><small>What does better mean?</small></div><span>→</span><div><span className="prepareFlowStep">3</span><strong>Rules</strong><small>What must be respected?</small></div><span>→</span><div><span className="prepareFlowStep">4</span><strong>Scenario</strong><small>What assumptions apply?</small></div><span>→</span><div><span className="prepareFlowStep">5</span><strong>Solve & compare</strong><small>Optimized vs baseline</small></div></section>
   <Alert type="info">Guided Optimization creates <strong>linear LP/MILP</strong> models. Use Advanced when coefficients or bounds must reference parameters, Data Assets, or custom solver options.</Alert>
   <section className="card"><div className="cardHeader"><div><h2>Decision models</h2><p>{items.length} models in this workspace.</p></div>{canWrite&&items.length===0&&<button type="button" className="button primaryButton" onClick={()=>setMode("WIZARD")}>Create first decision model</button>}</div>
   {items.length?<div className="optModelGrid">{items.map(x=>{const r=runFor(x.id);return <article className="optModelCard" key={x.id}><div className="mlModelCardHeader"><span className="prepareKind">{x.problem_type}</span><span className={`statusBadge ${x.enabled?"status-success":"status-blocked"}`}>{x.enabled?"ACTIVE":"DISABLED"}</span></div><div><h3>{x.name}</h3><p>{x.description||"No description"}</p></div><div className="optModelStructure"><div><small>DECISIONS</small><strong>{x.variables?.length||0}</strong></div><div><small>RULES</small><strong>{x.constraints?.filter(c=>c.enabled).length||0}</strong></div><div><small>SCENARIOS</small><strong>{x.scenarios?.length||0}</strong></div></div><div className="optLastResult"><small>LATEST RESULT</small>{r?<><strong>{r.status}</strong><span>Objective {r.objective_value??"—"}{r.improvement_percent!=null?` · ${Number(r.improvement_percent).toFixed(2)}% improvement`:""}</span></>:<><strong>Not solved</strong><span>Open the model to validate and run it.</span></>}</div><div className="tableActions"><Link className="button primaryButton smallButton" href={`/app/optimization/${x.id}`}>{r?"Open decision":"Configure & solve"}</Link>{canWrite&&<button type="button" className="button dangerButton smallButton" onClick={()=>remove(x)}>Delete</button>}</div></article>})}</div>:<EmptyState title="No decision models yet" description="Start with the business decision. Guided Optimization will create the LP/MILP structure for you."/>}</section>
  </>}
  {mode==="ADVANCED"&&<>
   <Alert type="info">Advanced mode exposes the OptimizationModel object directly. After creation, configure parameters, variable bounds, linear expressions, scenarios and solver adapters on the model detail page.</Alert>
   {canWrite&&<section className="card"><div className="cardHeader"><div><h2>{editing?"Edit":"Create"} OptimizationModel</h2><p>Choose LP or MILP explicitly. This is the technical entry point.</p></div>{!editing&&<button type="button" className="button secondaryButton" onClick={()=>setEditing({})}>+ Model</button>}</div>{editing&&<OptimizationModelForm workspaceId={activeWorkspace.id} initialValue={editing.id?editing:null} onSubmit={saveAdvanced} onCancel={()=>setEditing(undefined)} isSaving={saving}/>}</section>}
   <section className="card"><div className="cardHeader"><div><h2>Technical model inventory</h2><p>Direct access to existing OptimizationModel definitions.</p></div></div>{items.length?<div className="dataTableWrap"><table className="dataTable"><thead><tr><th>Model</th><th>Type</th><th>Variables</th><th>Constraints</th><th>Solvers</th><th>Asset</th><th>Actions</th></tr></thead><tbody>{items.map(x=><tr key={x.id}><td><Link href={`/app/optimization/${x.id}`}><strong>{x.name}</strong></Link><small className="tableSubtext">{x.description||"No description"}</small></td><td>{x.problem_type}</td><td>{x.variables?.length||0}</td><td>{x.constraints?.length||0}</td><td>{x.solver_configs?.length||0}</td><td>{x.data_asset?"OPTIMIZATION_MODEL":"—"}</td><td><div className="tableActions"><Link className="button smallButton primaryButton" href={`/app/optimization/${x.id}`}>Open</Link>{canWrite&&<button type="button" className="button smallButton secondaryButton" onClick={()=>setEditing(x)}>Edit</button>}</div></td></tr>)}</tbody></table></div>:<EmptyState title="No models" description="Create a guided or advanced model."/>}</section>
  </>}
 </div>;
}
