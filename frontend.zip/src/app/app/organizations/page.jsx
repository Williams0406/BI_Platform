"use client";

import { useState } from "react";

import ManageTabs from "@/components/manage/ManageTabs";
import Alert from "@/components/ui/Alert";
import EmptyState from "@/components/ui/EmptyState";
import OrganizationForm from "@/components/workspaces/OrganizationForm";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import {
  createOrganization,
  deleteOrganization,
  updateOrganization,
} from "@/lib/services/workspaces";
import { getApiErrorMessage } from "@/lib/utils/errors";

function roleLabel(role) {
  return {
    OWNER: "Propietario",
    ADMIN: "Administrador",
    BUILDER: "Constructor",
    ANALYST: "Analista",
    VIEWER: "Visualizador",
  }[role] || role || "Sin rol";
}

export default function OrganizationsPage() {
  const { organizations, workspaces, refresh, isLoading } = useWorkspace();
  const [showCreate, setShowCreate] = useState(false);
  const [editing, setEditing] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });

  async function handleCreate(payload) {
    setSubmitting(true);
    setMessage({ type: "", text: "" });
    try {
      await createOrganization(payload);
      await refresh();
      setShowCreate(false);
      setMessage({ type: "success", text: "Organización creada correctamente." });
    } catch (error) {
      setMessage({ type: "error", text: getApiErrorMessage(error) });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleUpdate(payload) {
    if (!editing) return;
    setSubmitting(true);
    setMessage({ type: "", text: "" });
    try {
      await updateOrganization(editing.id, payload);
      await refresh();
      setEditing(null);
      setMessage({ type: "success", text: "Organización actualizada correctamente." });
    } catch (error) {
      setMessage({ type: "error", text: getApiErrorMessage(error) });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(organization) {
    const relatedWorkspaces = workspaces.filter(
      (workspace) => workspace.organization === organization.id,
    ).length;
    const suffix = relatedWorkspaces
      ? ` También se eliminarán ${relatedWorkspaces} workspace(s) relacionados.`
      : "";

    if (!window.confirm(`¿Eliminar la organización "${organization.name}"?${suffix}`)) return;

    setMessage({ type: "", text: "" });
    try {
      await deleteOrganization(organization.id);
      await refresh();
      setMessage({ type: "success", text: "Organización eliminada." });
    } catch (error) {
      setMessage({ type: "error", text: getApiErrorMessage(error) });
    }
  }

  return (
    <div className="pageStack">
      <section className="pageHeader pageHeaderActions">
        <div>
          <p className="eyebrow">Manage · Access context</p>
          <h1>Organizations</h1>
          <p>
            Organizations group workspaces and define your organization-level role. Permissions continue to be enforced by the backend.
          </p>
        </div>
        <button type="button" className="button buttonPrimary" onClick={() => setShowCreate((value) => !value)}>
          {showCreate ? "Cerrar formulario" : "Nueva organización"}
        </button>
      </section>

      <ManageTabs />

      {message.text ? <Alert type={message.type}>{message.text}</Alert> : null}

      {showCreate ? (
        <section className="card">
          <div className="cardHeader">
            <div>
              <p className="eyebrow">CREATE</p>
              <h2>Nueva organización</h2>
            </div>
          </div>
          <OrganizationForm
            onSubmit={handleCreate}
            onCancel={() => setShowCreate(false)}
            submitting={submitting}
          />
        </section>
      ) : null}

      {editing ? (
        <section className="card">
          <div className="cardHeader">
            <div>
              <p className="eyebrow">EDIT</p>
              <h2>{editing.name}</h2>
            </div>
          </div>
          <OrganizationForm
            initialValue={editing}
            onSubmit={handleUpdate}
            onCancel={() => setEditing(null)}
            submitting={submitting}
          />
        </section>
      ) : null}

      <section className="card">
        <div className="cardHeader">
          <div>
            <p className="eyebrow">AVAILABLE</p>
            <h2>Mis organizaciones</h2>
          </div>
          <span className="countBadge">{organizations.length}</span>
        </div>

        {isLoading && organizations.length === 0 ? (
          <p className="muted">Cargando organizaciones...</p>
        ) : organizations.length === 0 ? (
          <EmptyState
            title="Aún no tienes organizaciones"
            description="Crea la primera organización para comenzar a crear workspaces."
          />
        ) : (
          <div className="tableWrap">
            <table className="dataTable">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Slug</th>
                  <th>Estado</th>
                  <th>Mi rol</th>
                  <th>Workspaces</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {organizations.map((organization) => {
                  const role = organization.current_user_role;
                  const canEdit = ["OWNER", "ADMIN"].includes(role);
                  const canDelete = role === "OWNER";
                  const workspaceCount = workspaces.filter(
                    (workspace) => workspace.organization === organization.id,
                  ).length;

                  return (
                    <tr key={organization.id}>
                      <td><strong>{organization.name}</strong></td>
                      <td><code>{organization.slug}</code></td>
                      <td><span className={`statusBadge status-${organization.status}`}>{organization.status}</span></td>
                      <td>{roleLabel(role)}</td>
                      <td>{workspaceCount}</td>
                      <td>
                        <div className="tableActions">
                          <button
                            type="button"
                            className="button buttonGhost buttonSmall"
                            onClick={() => setEditing(organization)}
                            disabled={!canEdit}
                            title={canEdit ? "Editar" : "Solo OWNER o ADMIN puede editar"}
                          >
                            Editar
                          </button>
                          <button
                            type="button"
                            className="button buttonDanger buttonSmall"
                            onClick={() => handleDelete(organization)}
                            disabled={!canDelete}
                            title={canDelete ? "Eliminar" : "Solo OWNER puede eliminar"}
                          >
                            Eliminar
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
