"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const ITEMS = [
  { label: "Overview", href: "/app/data" },
  { label: "Sources", href: "/app/data-sources" },
  { label: "Catalog", href: "/app/data-assets" },
  { label: "Model", href: "/app/data-model" },
];

export default function DataHubTabs() {
  const pathname = usePathname();
  return (
    <nav className="dataHubTabs" aria-label="Data workspace">
      {ITEMS.map((item) => {
        const active = pathname === item.href || (item.href !== "/app/data" && pathname.startsWith(`${item.href}/`));
        return <Link className={active ? "active" : ""} href={item.href} key={item.href}>{item.label}</Link>;
      })}
    </nav>
  );
}
