"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const TABS = [
  { label: "Overview", href: "/app/manage" },
  { label: "Organizations", href: "/app/organizations" },
  { label: "Workspaces", href: "/app/workspaces" },
  { label: "Governance", href: "/app/governance" },
  { label: "Private connections", href: "/app/customer-gateway" },
  { label: "Platform health", href: "/app/operations" },
];

export default function ManageTabs() {
  const pathname = usePathname();
  return (
    <nav className="manageTabs" aria-label="Manage">
      {TABS.map((tab) => {
        const active = pathname === tab.href || pathname.startsWith(`${tab.href}/`);
        return <Link key={tab.href} className={active ? "manageTab active" : "manageTab"} href={tab.href}>{tab.label}</Link>;
      })}
    </nav>
  );
}
