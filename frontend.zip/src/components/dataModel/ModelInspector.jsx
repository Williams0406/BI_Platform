"use client";

import Link from "next/link";

export default function ModelInspector({ table, source, relations, tables }) {
  if (!table) return <aside className="modelInspector empty"><div><strong>Select a table</strong><span>Inspect fields, keys and relationships without leaving the model canvas.</span></div></aside>;

  const inbound = relations.filter((relation) => relation.target_table === table.id);
  const outbound = relations.filter((relation) => relation.source_table === table.id);
  const tableById = Object.fromEntries(tables.map((item) => [item.id, item]));

  return <aside className="modelInspector">
    <div className="modelInspectorHeader">
      <div><span className="eyebrow">Table</span><h2>{table.table_name}</h2><p>{table.schema_name} · {source?.name || "Source"}</p></div>
      <Link href={`/app/data-model/${table.id}`} className="button secondaryButton compactButton">Open</Link>
    </div>

    <div className="modelInspectorStats">
      <div><span>Fields</span><strong>{table.fields?.length || 0}</strong></div>
      <div><span>Relations</span><strong>{inbound.length + outbound.length}</strong></div>
      <div><span>Mode</span><strong>{source?.mode || "—"}</strong></div>
    </div>

    <section className="modelInspectorSection"><h3>Definition</h3><dl>
      <div><dt>Object</dt><dd>{table.object_type}</dd></div>
      <div><dt>Primary key</dt><dd>{(table.primary_key_columns || []).join(", ") || "—"}</dd></div>
      <div><dt>Row version</dt><dd>{table.row_version_column || "—"}</dd></div>
    </dl></section>

    <section className="modelInspectorSection"><h3>Fields</h3><div className="inspectorFieldList">{(table.fields || []).map((field) => <div key={field.id}><span className="inspectorFieldKey">{field.is_primary_key ? "PK" : ""}</span><span><strong>{field.business_name || field.name}</strong>{field.business_name && <small>{field.name}</small>}</span><code>{field.logical_type}</code></div>)}</div></section>

    <section className="modelInspectorSection"><h3>Relationships</h3>{inbound.length + outbound.length === 0 ? <p className="mutedText">No registered relationships.</p> : <div className="inspectorRelationList">
      {outbound.map((relation) => <div key={relation.id}><span>OUT</span><p><strong>{relation.name}</strong><small>→ {tableById[relation.target_table]?.table_name || relation.target}</small></p></div>)}
      {inbound.map((relation) => <div key={relation.id}><span>IN</span><p><strong>{relation.name}</strong><small>← {tableById[relation.source_table]?.table_name || relation.source}</small></p></div>)}
    </div>}</section>
  </aside>;
}
