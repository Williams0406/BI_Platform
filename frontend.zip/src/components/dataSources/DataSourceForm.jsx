"use client";

import { useEffect, useMemo, useState } from "react";

const MODES = [
  { value: "MANAGED", label: "Managed / Plataforma" },
  { value: "EXTERNAL", label: "External" },
  { value: "PRIVATE_GATEWAY", label: "Private Gateway" },
];

const ENGINES = [
  { value: "PLATFORM_POSTGRES", label: "PostgreSQL administrado" },
  { value: "POSTGRESQL", label: "PostgreSQL" },
  { value: "SQLSERVER", label: "Microsoft SQL Server" },
  { value: "OTHER", label: "Otro" },
];

const STATUSES = ["DRAFT", "ACTIVE", "UNAVAILABLE", "ARCHIVED"];

function metadataFromSource(source) {
  return {
    host: source?.connection_metadata?.host || "",
    port: source?.connection_metadata?.port || "",
    database: source?.connection_metadata?.database || "",
    user: source?.connection_metadata?.user || "",
    sslmode: source?.connection_metadata?.sslmode || "prefer",
    server: source?.connection_metadata?.server || "",
    driver: source?.connection_metadata?.driver || "ODBC Driver 18 for SQL Server",
    trusted_connection: Boolean(source?.connection_metadata?.trusted_connection),
    encrypt: source?.connection_metadata?.encrypt ?? true,
    trust_server_certificate: Boolean(source?.connection_metadata?.trust_server_certificate),
    connect_timeout: source?.connection_metadata?.connect_timeout || 5,
  };
}

export default function DataSourceForm({ source, workspaceId, onSubmit, onCancel, isSaving }) {
  const [form, setForm] = useState({
    name: "",
    mode: "EXTERNAL",
    engine: "POSTGRESQL",
    status: "DRAFT",
    can_read: true,
    can_write: false,
    can_ddl: false,
    metadata: metadataFromSource(null),
  });

  useEffect(() => {
    if (!source) return;
    setForm({
      name: source.name || "",
      mode: source.mode || "EXTERNAL",
      engine: source.engine || "POSTGRESQL",
      status: source.status || "DRAFT",
      can_read: Boolean(source.can_read),
      can_write: Boolean(source.can_write),
      can_ddl: Boolean(source.can_ddl),
      metadata: metadataFromSource(source),
    });
  }, [source]);

  const isManaged = form.mode === "MANAGED";
  const isPrivateGateway = form.mode === "PRIVATE_GATEWAY";
  const isPostgres = form.engine === "POSTGRESQL";
  const isSqlServer = form.engine === "SQLSERVER";

  const availableEngines = useMemo(() => {
    if (isManaged) return ENGINES.filter((item) => item.value === "PLATFORM_POSTGRES");
    return ENGINES.filter((item) => item.value !== "PLATFORM_POSTGRES");
  }, [isManaged]);

  function updateField(event) {
    const { name, value, type, checked } = event.target;
    setForm((current) => ({ ...current, [name]: type === "checkbox" ? checked : value }));
  }

  function updateMetadata(event) {
    const { name, value, type, checked } = event.target;
    setForm((current) => ({
      ...current,
      metadata: {
        ...current.metadata,
        [name]: type === "checkbox" ? checked : value,
      },
    }));
  }

  function handleModeChange(event) {
    const mode = event.target.value;
    setForm((current) => ({
      ...current,
      mode,
      engine: mode === "MANAGED" ? "PLATFORM_POSTGRES" : current.engine === "PLATFORM_POSTGRES" ? "POSTGRESQL" : current.engine,
      can_read: true,
      can_write: mode === "MANAGED" ? true : current.can_write,
      can_ddl: mode === "MANAGED" ? true : current.can_ddl,
    }));
  }

  function buildMetadata() {
    if (isManaged || isPrivateGateway) return {};
    if (isPostgres) {
      const output = {
        host: form.metadata.host,
        database: form.metadata.database,
        user: form.metadata.user,
        sslmode: form.metadata.sslmode || "prefer",
        connect_timeout: Number(form.metadata.connect_timeout || 5),
      };
      if (form.metadata.port) output.port = Number(form.metadata.port);
      return output;
    }
    if (isSqlServer) {
      return {
        server: form.metadata.server,
        database: form.metadata.database,
        user: form.metadata.user,
        driver: form.metadata.driver || "ODBC Driver 18 for SQL Server",
        trusted_connection: Boolean(form.metadata.trusted_connection),
        encrypt: Boolean(form.metadata.encrypt),
        trust_server_certificate: Boolean(form.metadata.trust_server_certificate),
        connect_timeout: Number(form.metadata.connect_timeout || 5),
      };
    }
    return {};
  }

  function submit(event) {
    event.preventDefault();
    onSubmit({
      workspace: workspaceId,
      name: form.name.trim(),
      mode: form.mode,
      engine: form.engine,
      status: form.status,
      can_read: form.can_read,
      can_write: form.can_write,
      can_ddl: form.can_ddl,
      connection_metadata: buildMetadata(),
    });
  }

  return (
    <form className="inlineForm" onSubmit={submit}>
      <div className="formGrid twoColumns">
        <label className="field"><span>Nombre</span><input name="name" required value={form.name} onChange={updateField} /></label>
        <label className="field"><span>Modo</span><select name="mode" value={form.mode} onChange={handleModeChange}>{MODES.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
        <label className="field"><span>Motor</span><select name="engine" value={form.engine} onChange={updateField}>{availableEngines.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
        <label className="field"><span>Estado</span><select name="status" value={form.status} onChange={updateField}>{STATUSES.map((item) => <option key={item} value={item}>{item}</option>)}</select></label>
      </div>

      {!isManaged && !isPrivateGateway && (isPostgres || isSqlServer) ? (
        <div className="subsectionCard">
          <div><h3>Metadatos de conexión</h3><p className="mutedText">Se guardan datos no sensibles. La contraseña nunca se persiste aquí.</p></div>
          <div className="formGrid twoColumns">
            {isPostgres ? <label className="field"><span>Host</span><input name="host" required value={form.metadata.host} onChange={updateMetadata} /></label> : <label className="field"><span>Server</span><input name="server" required value={form.metadata.server} onChange={updateMetadata} placeholder="SERVIDOR\\INSTANCIA" /></label>}
            <label className="field"><span>Database</span><input name="database" required value={form.metadata.database} onChange={updateMetadata} /></label>
            {!form.metadata.trusted_connection && <label className="field"><span>Usuario</span><input name="user" value={form.metadata.user} onChange={updateMetadata} /></label>}
            {isPostgres && <label className="field"><span>Puerto</span><input name="port" type="number" value={form.metadata.port} onChange={updateMetadata} placeholder="5432" /></label>}
            {isPostgres && <label className="field"><span>SSL mode</span><input name="sslmode" value={form.metadata.sslmode} onChange={updateMetadata} /></label>}
            {isSqlServer && <label className="field"><span>ODBC driver</span><input name="driver" value={form.metadata.driver} onChange={updateMetadata} /></label>}
            <label className="field"><span>Timeout (s)</span><input name="connect_timeout" type="number" min="1" max="60" value={form.metadata.connect_timeout} onChange={updateMetadata} /></label>
          </div>
          {isSqlServer && <div className="checkboxRow"><label><input type="checkbox" name="trusted_connection" checked={form.metadata.trusted_connection} onChange={updateMetadata} /> Trusted connection</label><label><input type="checkbox" name="encrypt" checked={form.metadata.encrypt} onChange={updateMetadata} /> Encrypt</label><label><input type="checkbox" name="trust_server_certificate" checked={form.metadata.trust_server_certificate} onChange={updateMetadata} /> Trust server certificate</label></div>}
        </div>
      ) : null}

      {isPrivateGateway && <div className="subsectionCard"><h3>Conexión privada</h3><p className="mutedText">Host, usuario y credenciales permanecerán en Customer Data Gateway. Esta definición solo identifica el motor y las capacidades lógicas.</p></div>}

      <div className="subsectionCard">
        <h3>Capacidades</h3>
        <div className="checkboxRow">
          <label><input type="checkbox" name="can_read" checked={form.can_read} onChange={updateField} /> READ</label>
          <label><input type="checkbox" name="can_write" checked={form.can_write} onChange={updateField} /> WRITE</label>
          <label><input type="checkbox" name="can_ddl" checked={form.can_ddl} onChange={updateField} /> DDL</label>
        </div>
      </div>

      <div className="formActions"><button type="submit" className="button primaryButton" disabled={isSaving}>{isSaving ? "Guardando..." : source ? "Guardar cambios" : "Crear Data Source"}</button><button type="button" className="button secondaryButton" onClick={onCancel}>Cancelar</button></div>
    </form>
  );
}
