"use client";

import { useState } from "react";

import AuthGuard from "@/components/auth/AuthGuard";
import Sidebar from "@/components/layout/Sidebar";
import Topbar from "@/components/layout/Topbar";

export default function AppShell({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <AuthGuard>
      <div className="appShell">
        <a className="skipLink" href="#main-content">Skip to main content</a>
        <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <div className="appMain">
          <Topbar onMenuClick={() => setSidebarOpen(true)} />
          <main className="pageContent" id="main-content" tabIndex={-1}>{children}</main>
        </div>
      </div>
    </AuthGuard>
  );
}
