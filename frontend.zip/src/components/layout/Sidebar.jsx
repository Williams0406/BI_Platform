"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

import Icon from "@/components/ui/Icon";
import { useWorkspace } from "@/lib/hooks/useWorkspace";
import {
  getNavigationGroupForPath,
  isNavigationItemActive,
  NAVIGATION_SECTIONS,
} from "@/lib/constants/navigation";

export default function Sidebar({ open, onClose }) {
  const pathname = usePathname();
  const { activeWorkspace, organizations } = useWorkspace();
  const organization = organizations.find((item) => item.id === activeWorkspace?.organization);
  const role = organization?.current_user_role;
  const canBuild = ["OWNER","ADMIN","BUILDER"].includes(role);
  const canAdminister = ["OWNER","ADMIN"].includes(role);
  const activeGroup = useMemo(() => getNavigationGroupForPath(pathname), [pathname]);
  const [expanded, setExpanded] = useState(() => activeGroup?.id || "data");

  useEffect(() => {
    if (activeGroup?.id) setExpanded(activeGroup.id);
  }, [activeGroup?.id]);

  function toggleGroup(id) {
    setExpanded((current) => (current === id ? "" : id));
  }

  return (
    <>
      {open ? <button type="button" className="sidebarBackdrop" onClick={onClose} aria-label="Close navigation" /> : null}
      <aside className={`sidebar ${open ? "sidebarOpen" : ""}`} aria-label="Primary navigation">
        <Link className="sidebarBrand" href="/app" onClick={onClose}>
          <div className="brandMark brandMarkShell">BI</div>
          <div className="sidebarBrandCopy">
            <strong>Intelligence</strong>
            <span>Decision workspace</span>
          </div>
        </Link>

        <nav className="sidebarNav" aria-label="Navegación principal">
          {NAVIGATION_SECTIONS.map((section) => {
            if (section.href) {
              const active = isNavigationItemActive(pathname, section.href);
              return (
                <Link
                  className={`navPrimaryItem ${active ? "navPrimaryItemActive" : ""}`}
                  href={section.href}
                  key={section.id}
                  onClick={onClose}
                >
                  <Icon name={section.icon} size={18} />
                  <span>{section.label}</span>
                </Link>
              );
            }

            const visibleItems = section.id === "manage"
              ? section.items.filter((item) => {
                  if (["/app/governance","/app/customer-gateway","/app/operations"].includes(item.href)) return canAdminister;
                  if (item.href === "/app/import-export") return canBuild;
                  return true;
                })
              : section.items;
            const groupActive = visibleItems.some((item) =>
              isNavigationItemActive(pathname, item.href),
            );
            const isExpanded = expanded === section.id;

            return (
              <div className={`navGroup ${groupActive ? "navGroupActive" : ""}`} key={section.id}>
                <button
                  type="button"
                  aria-expanded={isExpanded}
                  className="navGroupButton"
                  onClick={() => toggleGroup(section.id)}
                  type="button"
                >
                  <span className="navGroupButtonMain">
                    <Icon name={section.icon} size={18} />
                    <span>{section.label}</span>
                  </span>
                  <Icon
                    className={`navChevron ${isExpanded ? "navChevronOpen" : ""}`}
                    name="chevronDown"
                    size={15}
                  />
                </button>

                {isExpanded ? (
                  <div className="navChildren">
                    {visibleItems.map((item) => {
                      const active = isNavigationItemActive(pathname, item.href);
                      return (
                        <Link
                          className={`navChildItem ${active ? "navChildItemActive" : ""}`}
                          href={item.href}
                          key={item.href}
                          onClick={onClose}
                        >
                          <Icon name={item.icon} size={16} />
                          <span>{item.label}</span>
                        </Link>
                      );
                    })}
                  </div>
                ) : null}
              </div>
            );
          })}
        </nav>

        <div className="sidebarFooter">
          <p>DATA → ANALYZE → DECIDE</p>
          <span>Workspace UX · Phase 12</span>
        </div>
      </aside>
    </>
  );
}
