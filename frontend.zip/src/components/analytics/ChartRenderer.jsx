"use client";

function formatMetricValue(value, metric = {}) {
  if (value === null || value === undefined) return "—";
  const number = Number(value);
  if (Number.isNaN(number)) return String(value);
  const decimals = metric.decimal_places ?? 2;
  if (metric.format_type === "PERCENT") return `${(number * 100).toFixed(decimals)}%`;
  if (metric.format_type === "INTEGER") return Math.round(number).toLocaleString();
  const formatted = number.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return metric.unit ? `${metric.unit} ${formatted}` : formatted;
}

function prepare(dataset) {
  const rows = dataset?.rows || [];
  const dimensions = dataset?.dimensions || [];
  const labels = rows.map((row, index) => {
    if (!dimensions.length) return `#${index + 1}`;
    return dimensions.map((dimension) => String(row[dimension.id] ?? "—")).join(" · ");
  });
  const values = rows.map((row) => Number(row.value) || 0);
  return { rows, dimensions, labels, values };
}

function TableChart({ dataset }) {
  const { rows, dimensions } = prepare(dataset);
  return <div className="tableWrap"><table className="dataTable"><thead><tr>{dimensions.map(d=><th key={d.id}>{d.name}</th>)}<th>{dataset?.metric?.name || "Value"}</th></tr></thead><tbody>{rows.map((row,index)=><tr key={index}>{dimensions.map(d=><td key={d.id}>{String(row[d.id]??"—")}</td>)}<td><strong>{formatMetricValue(row.value,dataset?.metric)}</strong></td></tr>)}</tbody></table></div>;
}

function CartesianChart({ dataset, mode }) {
  const { labels, values } = prepare(dataset);
  if (!values.length) return <p className="mutedText">Sin datos.</p>;
  const width=760,height=300,pad=44,plotW=width-pad*2,plotH=height-pad*2;
  const min=Math.min(0,...values),max=Math.max(0,...values); const range=max-min||1;
  const y=(v)=>pad+plotH-((v-min)/range)*plotH;
  const step=plotW/Math.max(values.length,1);
  const points=values.map((v,i)=>`${pad+step*i+step/2},${y(v)}`).join(" ");
  return <div className="svgChartWrap"><svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label={mode}>
    <line x1={pad} y1={pad} x2={pad} y2={height-pad} className="chartAxis"/><line x1={pad} y1={height-pad} x2={width-pad} y2={height-pad} className="chartAxis"/>
    {mode==="BAR"&&values.map((v,i)=>{const x=pad+step*i+step*.15; const baseline=y(0); const yy=Math.min(y(v),baseline); const h=Math.max(Math.abs(baseline-y(v)),1); return <g key={i}><rect x={x} y={yy} width={step*.7} height={h} className="chartBar"><title>{labels[i]}: {formatMetricValue(v,dataset.metric)}</title></rect></g>;})}
    {(mode==="LINE"||mode==="AREA")&&<>{mode==="AREA"&&<polygon points={`${pad+step/2},${height-pad} ${points} ${pad+step*(values.length-1)+step/2},${height-pad}`} className="chartArea"/>}<polyline points={points} className="chartLine"/>{values.map((v,i)=><circle key={i} cx={pad+step*i+step/2} cy={y(v)} r="4" className="chartPoint"><title>{labels[i]}: {formatMetricValue(v,dataset.metric)}</title></circle>)}</>}
    {labels.map((label,i)=><text key={i} x={pad+step*i+step/2} y={height-12} textAnchor="middle" className="chartTick">{label.length>12?`${label.slice(0,10)}…`:label}</text>)}
  </svg></div>;
}

function PieChart({ dataset, donut=false }) {
  const { labels, values }=prepare(dataset); const positive=values.map(v=>Math.max(v,0)); const total=positive.reduce((a,b)=>a+b,0);
  if(!total)return <p className="mutedText">Sin valores positivos para representar.</p>;
  const cx=160,cy=160,r=120; let angle=-Math.PI/2;
  const slices=positive.map((value,index)=>{const start=angle; const delta=value/total*Math.PI*2; const end=start+delta; angle=end; const x1=cx+r*Math.cos(start),y1=cy+r*Math.sin(start),x2=cx+r*Math.cos(end),y2=cy+r*Math.sin(end); const large=delta>Math.PI?1:0; return {index,value,path:`M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2} Z`};});
  return <div className="pieLayout"><svg viewBox="0 0 320 320" className="pieSvg">{slices.map(s=><path key={s.index} d={s.path} className={`pieSlice pieSlice${s.index%8}`}><title>{labels[s.index]}: {formatMetricValue(s.value,dataset.metric)}</title></path>)}{donut&&<circle cx={cx} cy={cy} r="62" className="donutHole"/>}</svg><div className="chartLegend">{labels.map((label,i)=><div key={i}><span className={`legendSwatch pieSlice${i%8}`}/><span>{label}</span><strong>{formatMetricValue(values[i],dataset.metric)}</strong></div>)}</div></div>;
}

function ScatterChart({ dataset }) {
  const { rows,dimensions }=prepare(dataset); if(!rows.length)return <p className="mutedText">Sin datos.</p>;
  const first=dimensions[0]; const points=rows.map((row,index)=>({x:Number(row[first?.id]),y:Number(row.value),label:first?String(row[first.id]):`#${index+1}`})); const numeric=points.every(p=>Number.isFinite(p.x)); if(!numeric) points.forEach((p,i)=>p.x=i+1);
  const xs=points.map(p=>p.x), ys=points.map(p=>p.y); const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(0,...ys),maxY=Math.max(0,...ys); const w=760,h=300,pad=44; const x=v=>pad+((v-minX)/(maxX-minX||1))*(w-pad*2); const y=v=>pad+(h-pad*2)-((v-minY)/(maxY-minY||1))*(h-pad*2);
  return <div className="svgChartWrap"><svg viewBox={`0 0 ${w} ${h}`}><line x1={pad} y1={pad} x2={pad} y2={h-pad} className="chartAxis"/><line x1={pad} y1={h-pad} x2={w-pad} y2={h-pad} className="chartAxis"/>{points.map((p,i)=><circle key={i} cx={x(p.x)} cy={y(p.y)} r="6" className="chartPoint"><title>{p.label}: {formatMetricValue(p.y,dataset.metric)}</title></circle>)}</svg>{!numeric&&<p className="mutedText">SCATTER usa el índice categórico como eje X porque la primera dimensión no es numérica.</p>}</div>;
}

export default function ChartRenderer({ chart, dataset, title }) {
  const type=chart?.chart_type||"TABLE";
  if(!dataset)return <p className="mutedText">Ejecuta el dataset para visualizar el gráfico.</p>;
  if(type==="KPI") return <div className="kpiVisual"><span>{title||chart?.name||dataset?.metric?.name}</span><strong>{formatMetricValue(dataset.rows?.[0]?.value,dataset.metric)}</strong><small>{dataset.cached?"cache":"consulta nueva"}</small></div>;
  if(type==="TABLE") return <TableChart dataset={dataset}/>;
  if(["BAR","LINE","AREA"].includes(type)) return <CartesianChart dataset={dataset} mode={type}/>;
  if(type==="PIE") return <PieChart dataset={dataset}/>;
  if(type==="DONUT") return <PieChart dataset={dataset} donut/>;
  if(type==="SCATTER") return <ScatterChart dataset={dataset}/>;
  return <TableChart dataset={dataset}/>;
}

export { formatMetricValue };
